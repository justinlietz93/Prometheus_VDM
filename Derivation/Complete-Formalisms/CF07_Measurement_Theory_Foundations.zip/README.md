# CF07: Complete Formalism — Measurement Theory Foundations (Decoherence and Born Rule)

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF07** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF07 technical content (claims, gates, derivations, VDM integration)
- `references.bib` — full bibliography (DOI-forward where available)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF07 source SHA256 (from `Derivation/Complete-Formalisms/CF07_Measurement_Theory_Decoherence_Born_Rule.md`): `b01616073086f5490899f527c4e90ea2b8aaae21972bad8c20633d20bf12494d`
