# CF11 — Whitepaper Build (ArXiv-style)

This directory contains the **publication-ready LaTeX sources** for:

**CF11: Complete Formalism — Dark Sector Emergence from Metriplectic Dynamics**

## Contents

- `main.tex` — arXiv-style wrapper + metadata
- `content.tex` — CF11 body (LaTeX, edited from the canonical markdown for publication)
- `references.bib` — bibliography database
- `arxiv.sty` — arXiv-style package (vendored for portability)
- `orcid.pdf` — ORCID icon asset
- `License.txt` — repository license snapshot

## Build

From this folder:

```bash
pdflatex -interaction=nonstopmode main.tex
bibtex main  # or: bibtex8 main (some minimal TeX installs)
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

The output PDF is renamed to `CF11_Dark_Sector_Metriplectic_Complete.pdf` for archival.

## Provenance

- Canon snapshot commit (per `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- Canon source markdown (in repository snapshot):
  `Derivation/Complete-Formalisms/CF11_Dark_Sector_Metriplectic_Complete.md`
- SHA256 of the exported markdown used to seed this build (see `/mnt/data/CF11_Dark_Sector_Metriplectic_Complete.md`):

  `2cb8582711d3ba909c85000533fb1a8776680d91a77b18f43f14d6b5b605ae42`

## Notes

- This is a **Complete Formalism** document: it specifies claims + gates + an implementation/testing contract.
- Scope classification is **derived-limit** (cosmology-facing interpretation built on axiom-core metriplectic structure).
