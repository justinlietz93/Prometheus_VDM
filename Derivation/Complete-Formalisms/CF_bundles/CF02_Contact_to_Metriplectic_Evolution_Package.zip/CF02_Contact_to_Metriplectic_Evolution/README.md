# CF02: Complete Formalism — Contact to Metriplectic Evolution

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF02** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF02 technical content (claims, gates, derivations, example)
- `references.bib` — full bibliography (DOI-forward)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF02 source SHA256 (from `Derivation/Complete-Formalisms/PROVENANCE_index.json`): `a7f5071514fa3c949a50e214a25bde68a46ec5226470a909f22532097e7e7091`

