# CF10 — Whitepaper Build (ArXiv-style)

This directory contains the **publication-ready LaTeX sources** for:

**CF10: Complete Formalism — VDM Lattice Hydrodynamics, Continuum Limit, and Regularity Program**

## Contents

- `main.tex` — arXiv-style wrapper + metadata
- `content.tex` — CF10 body (LaTeX, edited from the canonical markdown for publication)
- `references.bib` — bibliography database
- `arxiv.sty` — arXiv-style package (vendored for portability)
- `orcid.pdf` — ORCID icon asset
- `License.txt` — repository license snapshot

## Build

From this folder:

```bash
pdflatex -interaction=nonstopmode main.tex
bibtex main  # or: bibtex8 main (some minimal TeX installs)
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

The output PDF is renamed to `CF10_Lattice_Fluids_Continuum_and_Regularity_Program.pdf` for archival.

## Provenance

- Canon snapshot commit (per `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- Canon source markdown (in repository snapshot):
  `Derivation/Complete-Formalisms/CF10_Lattice_Fluids_Continuum_and_Regularity_Program.md`
- SHA256 of the exported markdown used to seed this build (see `/mnt/data/CF10_Lattice_Fluids_Continuum_and_Regularity_Program.md`):

  `a4a93b400facc5bb66aea568d370fd0224ad7693d1982d9aa23178dd8bb2d38e`

## Notes

- This is a **Complete Formalism** document: it specifies claims + gates + an implementation/testing contract.
- No claim of a solved millennium problem is made; the Navier–Stokes component is stated **conditionally** (see Conjecture F1.A and Gate F1.3).
