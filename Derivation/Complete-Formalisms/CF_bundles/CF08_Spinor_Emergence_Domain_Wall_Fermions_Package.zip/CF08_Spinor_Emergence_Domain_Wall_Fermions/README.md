# CF08: Complete Formalism — Spinor Emergence via Domain-Wall Fermions (Nielsen–Ninomiya Defense)

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF08** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF08 technical content (claims, gates, derivations, VDM integration)
- `references.bib` — full bibliography (DOI-forward where available)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF08 source SHA256 (from `Derivation/Complete-Formalisms/CF08_Spinor_Emergence_Domain_Wall_Fermions.md`): `7a642811b021ccb374eb43735765a41baf33383673c88445c5b4be05eb3df9c6`
