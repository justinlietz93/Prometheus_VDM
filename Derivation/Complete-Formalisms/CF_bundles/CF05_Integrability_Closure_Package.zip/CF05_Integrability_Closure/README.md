# CF05: Complete Formalism — Integrability Closure

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF05** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF05 technical content (claims, gates, derivations, closure certificate schema)
- `references.bib` — full bibliography (DOI-forward where available)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF05 source SHA256 (from `Derivation/Complete-Formalisms/CF05_Integrability_Closure.md`): `8890add6beb6271c5a7ad15b7fb3ca0d9441ee53a3cc9f7adb229df27f737ac3`

