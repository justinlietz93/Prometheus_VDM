# CF01: Complete Formalism — Quantum Geometric Tensor to Metriplectic Brackets

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF01** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF01 technical content (claims, gates, derivations, appendices)
- `references.bib` — full bibliography (DOI-forward)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF01 source SHA256: `e294d535528e9e4cf2f666adc47fb0a9c0986600e0ca2caa192a1c18c3397b11`

