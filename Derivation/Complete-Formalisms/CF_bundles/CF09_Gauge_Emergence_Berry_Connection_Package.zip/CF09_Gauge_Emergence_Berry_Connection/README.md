# CF09: Complete Formalism — Gauge Field Emergence via Berry Connection in VDM (Weinberg–Witten Defense)

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF09** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF09 technical content (claims, gates, derivations, VDM integration)
- `references.bib` — full bibliography (DOI-forward where available)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF09 source SHA256 (from `/mnt/data/CF09_Gauge_Emergence_Berry_Connection.md`): `22d1a9ec34d5762182b563a1422c00d9fd0bca927ef8f8a4affe4562b49d0cda`

