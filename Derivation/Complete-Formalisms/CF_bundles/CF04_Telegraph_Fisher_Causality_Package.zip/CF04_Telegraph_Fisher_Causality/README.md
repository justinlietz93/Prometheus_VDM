# CF04: Complete Formalism — Telegraph–Fisher Causality

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF04** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF04 technical content (claims, gates, derivations, implementation notes)
- `references.bib` — full bibliography (DOI-forward where available)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF04 source SHA256 (from `Derivation/Complete-Formalisms/CF04_Telegraph_Fisher_Causality.md`): `5edfc44191766c8e25885f4560f6336491609eab56d813620cf7eb6f8f37480c`

