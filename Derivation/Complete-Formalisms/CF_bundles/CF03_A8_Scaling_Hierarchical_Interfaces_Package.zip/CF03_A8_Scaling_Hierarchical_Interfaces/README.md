# CF03: Complete Formalism — A8 Scaling Theorem (Hierarchical Tachyonic Interfaces)

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF03** as a standalone whitepaper (e.g., Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF03 technical content (claims, gates, derivations, extraction protocol)
- `references.bib` — full bibliography (DOI-forward)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF03 source SHA256 (from `Derivation/Complete-Formalisms/CF03_A8_Scaling_Hierarchical_Interfaces.md`): `0ff065faf617040d7a44df4869acede28a026f2f60b8ddb678b674fbf52b52db`
