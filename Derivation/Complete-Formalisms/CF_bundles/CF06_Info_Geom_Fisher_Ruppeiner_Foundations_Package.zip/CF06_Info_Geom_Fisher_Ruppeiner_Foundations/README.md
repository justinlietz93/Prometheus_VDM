# CF06: Complete Formalism — Information Geometry Foundations (Fisher and Ruppeiner)

This folder is a **self-contained arXiv-style LaTeX bundle** for publishing **CF06** as a standalone whitepaper (suitable for Zenodo upload + DOI minting).

## Contents

- `main.tex` — arXiv-style wrapper + metadata + bibliography plumbing
- `content.tex` — CF06 technical content (claims, gates, derivations, VDM integration)
- `references.bib` — full bibliography (DOI-forward where available)
- `arxiv.sty` — arXiv-style layout
- `orcid.pdf` — ORCID icon used in author block
- `License.txt` — project license

## Build

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

If `bibtex` is not available on your system, use `bibtex.original` (Debian/Ubuntu alt-link edge case):

```bash
bibtex.original main
```

The final artifact is `main.pdf`.

## Provenance

- Canon snapshot commit (from `PROVENANCE_manifest.json`): `91332f4cf89a52d239eaab6659b8df8d8b9f3202`
- CF06 source SHA256 (from `Derivation/Complete-Formalisms/CF06_Info_Geom_Fisher_Ruppeiner_Foundations.md`): `4bcec68906c71a8034cdd9a4143ae3811c35dac1a8122580969e26910a50cd00`
