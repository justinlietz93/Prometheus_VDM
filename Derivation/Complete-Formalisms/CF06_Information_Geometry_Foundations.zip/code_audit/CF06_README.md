# CF06 bundle manifest

## Files
- Paper: `/code_audit/CF06_Information_Geometry_Foundations.pdf`
- Reviewer-facing notebook (source): `/code_audit/CFN06_Information_Geometry_Reviewer_Facing.ipynb`
- Reviewer-facing notebook (executed): `/code_audit/CFN06_Information_Geometry_Reviewer_Facing.executed.ipynb`
- Lean4 companion: `/code_audit/CF06_information_geometry_companion.lean`
- SymPy companion: `/code_audit/CF06_sympy.py`

## SHA256
- paper: `3b231b175d58154df19e4293dab001e064d4b39377da427fcc1ed41588076bc9`
- jupyter_source: `68741791b6a9a79701833c2cd48d7ad5be92140aea6a8c713f21d29d53fcac51`
- jupyter_executed: `05be01ff14c5a0e08ad9b39d52efe34a98cc3facad5804d6339b243a1d395722`
- lean4 package "CF06_lean_package.zip": `9c4df67b07860e0a1b1f43a7b902d2fe3933d87aceaf61ae4afc434f3ef0c4e6`
- sympy: `cb6adc9ba5519ee3651acb5daffb7003126c55af6899c1b39feec62af3d52325`

## Run notes
1. Open the executed notebook for the finished reviewer-facing appendix.
2. Open the source notebook if you want to re-run or edit cells.
3. The notebook assumes the CF06 PDF is present at `/code_audit/CF06_Information_Geometry_Foundations.pdf`.
4. The Lean4 file is a compact companion for exact algebraic identities only; it is not a full formalization of CF06.
5. The SymPy file packages the exact symbolic checks used by the notebook and ends with `FINAL_RESULT: PASS` or `FINAL_RESULT: FAIL`.

## Scope
This bundle covers the Jupyter / SymPy / Lean4 companion layer for CF06 in reviewer-facing form. It does not claim full formalization of every information-geometric theorem in Lean4.
