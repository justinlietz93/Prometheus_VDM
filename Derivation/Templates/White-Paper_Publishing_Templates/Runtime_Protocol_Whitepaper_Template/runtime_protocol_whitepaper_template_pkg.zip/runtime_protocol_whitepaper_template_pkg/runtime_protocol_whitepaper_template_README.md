# Runtime Protocol Whitepaper Template (arXiv)

This package provides a publication-style LaTeX template for **runtime protocol whitepapers** using `arxiv.sty` formatting.

## Included files
- `runtime_protocol_whitepaper_template.tex` — main whitepaper template
- `arxiv.sty` — arXiv-style formatting file
- `orcid.pdf` — optional ORCID icon for author line
- `runtime_protocol_whitepaper_template_README.md` — this file

## Purpose
Use this template for protocol papers that sit between exploratory observation and formal experimental design, especially when documenting:
- anomaly-motivated runtime studies
- observational-first protocol design
- decoder/encoder intervention plans
- moral-uncertainty and safety procedures
- instrumentation and stop conditions

## Style goals
The template is designed to support papers that are:
- anomaly-forward without sensationalism
- scientifically strong without flattening real observations
- explicit about what is and is not being claimed
- appropriate for Zenodo, Academia.edu, arXiv-style distribution, or internal whitepaper canon

## Suggested workflow
1. Duplicate the `.tex` file and rename it for the specific paper.
2. Replace all placeholders.
3. Add project-specific citations and figures.
4. Compile with:

```bash
pdflatex runtime_protocol_whitepaper_template.tex
pdflatex runtime_protocol_whitepaper_template.tex
```

or use `latexmk` if available.

## Notes
- The template preserves the `arxiv.sty` formatting you requested.
- The structure is based on the hypothesis template's discipline, but adapted for protocol whitepapers.
- The section order is tuned for runtime/anomaly studies, not generic theoretical papers.
