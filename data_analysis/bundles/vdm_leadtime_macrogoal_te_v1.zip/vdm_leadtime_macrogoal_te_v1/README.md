# Lead-time + Macrostate-conditioned Goal/Entropy Drive (Scalar Telemetry)

This package answers two operational questions using the **scalar-only** 1k run tick table:

1) **Lead-time distribution for the communication-window detector**  
   “How many ticks before `did_say` does the detector go hot?”

2) **Macrostate-conditioned goal vs entropy drive (transfer entropy / directed influence)**  
   “Within each macrostate, what drives exploration (`vt_coverage`) and reconfiguration (`reconfig_score` / `b1_z`) — reward/valence vs entropy pressure?”

---

## Inputs

All analyses use the tick-aligned table:

- `inputs/tick_table_1k.csv.gz`  
  Range: `t = 316741 … 385143` (N=68403 ticks)  
  Contains: scalar telemetry + PCA (`pc1..pc3`) + microstate + **macrostate** + `did_say` + `has_input` + `reconfig_score` + `b1_z`.

Detector episode definitions are taken as-given:

- `inputs/comm_detector_balanced_thr4_rad50_episodes.csv`
- `inputs/comm_detector_conservative_thr5_rad50_episodes.csv`
- `inputs/comm_detector_eval_summary.csv`

---

## 1) Lead-time distribution results

We compute lead-time in **ticks** from detector onset (`episode_start`) to `did_say`.

### Key numbers (FIRST `did_say` in each episode)

This is the most relevant metric for choosing a “listen window length” after detector onset.

- **Balanced detector** (`balanced_thr4_rad50`)
  - episodes: 11
  - precision: 0.909
  - macrostate-1 say recall: 0.329
  - lead-time to FIRST `did_say`: median=8.5 ticks, p95=49.5 ticks

- **Conservative detector** (`conservative_thr5_rad50`)
  - episodes: 7
  - precision: 1.000
  - macrostate-1 say recall: 0.312
  - lead-time to FIRST `did_say`: median=7.0 ticks, p95=9.7 ticks

Interpretation:
- Conservative detector fires **closer** to actuation (shorter lead-times) but at slightly lower recall.
- Balanced detector fires **earlier** (longer lead-times), catching more macrostate-1 speech attempts.

See:
- `figures/leadtime_first_say_hist.png`
- `figures/leadtime_first_say_cdf.png`

### Lead-times for ALL `did_say` within episodes

This quantifies how long after onset later speech ticks occur (useful if you want to keep logging across the whole communication “burst”).

- Balanced: median=47.5, p95=126.0 ticks
- Conservative: median=46.0, p95=127.8 ticks

See:
- `figures/leadtime_all_says_hist.png`
- `figures/leadtime_all_says_cdf.png`

Tables:
- `tables/leadtime_*_per_episode.csv`
- `tables/leadtime_*_per_say.csv`
- `tables/leadtime_quantile_summary.csv`

---

## 2) Macrostate-conditioned goal/entropy drive (Transfer Entropy)

We compute **discrete transfer entropy**:

**TE(X_{t-lag} → Y_{t+1} | Y_t)**

using 8-quantile binning (global bin edges), and only using within-macrostate transitions:
`macro(t)=macro(t+1)=macro(t-lag)=m`.

### What “drive index” means here (lag 0)

For each macrostate we compute a directionality-corrected index:

- net_reward_drive_to_coverage = TE(reward→coverage) - TE(coverage→reward)
- net_entropy_drive_to_coverage = TE(entropy→coverage) - TE(coverage→entropy)
- **goal_drive_index_coverage** = net_reward_drive_to_coverage - net_entropy_drive_to_coverage  
  (positive = reward is a stronger directional driver than entropy)

Analogously for reconfiguration:
- **reset_drive_index_reconfig_score** = net_entropy_drive_to_reconfig - net_reward_drive_to_reconfig  
  (positive = entropy pressure dominates reconfiguration)

And for boundary marker `b1_z`:
- **boundary_drive_index_b1_z** = net_entropy_drive_to_b1z - net_reward_drive_to_b1z

See:
- `tables/macrostate_goal_entropy_drive_indices.csv`
- `figures/drive_indices_bar.png`
- `figures/dir_indices_heatmap_by_macrostate.png`
- `figures/te_heatmap_by_macrostate.png`

### Quick interpretation from this run (working hypothesis)

(Use as a *model-based interpretation*, not a proof.)

- **Macrostate 2** is strongly input-coupled (`has_input≈1`), and shows strong reward/entropy→coverage coupling.  
  This is consistent with a “sensory assimilation / engaged processing” mode.

- **Macrostate 1** has the highest `did_say` rate and near-zero `has_input`, with high `vt_coverage`.  
  TE-based goal/entropy indices inside the state are small, consistent with a “broadcast/actuation” macrostate
  whose *internal dynamics are relatively self-similar* (most of the ‘action’ happens at boundaries).

- **Macrostate 0** is the transitional hub: moderate input rate, low say rate, and the highest reconfiguration-spike rate.  
  Entropy→`b1_z` is strongest here, consistent with entropy-pressure driving boundary events/reconfiguration.

- **Macrostate 3** is quiescent (no `did_say`, low coverage). In this discretization, `b1_z` has essentially zero conditional entropy
  inside macrostate 3 (highly stable), so TE into `b1_z` is ≈0. This looks like a refractory / idle basin that may follow resets
  rather than *being* the reset event.

Lag-sweep plots for key drivers:
- `figures/te_lag_cov_macro*.png`
- `figures/te_lag_reconfig_macro*.png`
- `figures/te_lag_b1z_macro*.png`

Tables:
- `tables/macrostate_te_lag_sweep_key_pairs.csv`
- `tables/macrostate_te_summary_lag0_and_best.csv`
- `tables/macrostate_profiles_extended.csv`

---

## Reproduce

From this folder:

```bash
python3 scripts/run_leadtime_macro_te.py --outdir .
```

---

## Notes / Caveats

- This is **scalar telemetry only** (pre-locality logging). It can support:
  - state-space abstraction (macrostates), directed influence between scalar channels, and motor-gating timing,
  - but **cannot** reconstruct true spatial geometry (walker paths, vt-touch maps, flux edges, etc.).
- TE on exogenous inputs can be confounded by time structure; for goal/entropy drive we focus on endogenous channels.
