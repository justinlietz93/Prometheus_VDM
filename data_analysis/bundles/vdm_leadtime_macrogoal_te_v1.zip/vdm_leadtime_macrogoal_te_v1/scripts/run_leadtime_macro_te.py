#!/usr/bin/env python3
"""
Lead-time + macrostate-conditioned TE analysis (scalar-only).

Inputs (default relative to this file's parent directory):
  - inputs/tick_table_1k.csv.gz
  - inputs/comm_detector_balanced_thr4_rad50_episodes.csv
  - inputs/comm_detector_conservative_thr5_rad50_episodes.csv

Outputs:
  - tables/*
  - figures/*

Notes:
  - TE estimator is discrete (quantile binning; 8 bins) and computes TE(X_{t-lag} -> Y_{t+1} | Y_t).
  - Macrostate-conditioned TE uses only within-macrostate transitions (macro(t)=macro(t+1)=macro(t-lag)=m).
"""
import argparse, math, gzip
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams.update({'figure.dpi': 150})

def quantile_edges(x, n_bins=8):
    x = np.asarray(x)
    qs = np.linspace(0,1,n_bins+1)
    edges = np.quantile(x, qs)
    edges = np.unique(edges)
    if len(edges) < 2:
        edges = np.array([np.min(x), np.max(x)+1e-9])
    return edges

def discretize_with_edges(x, edges):
    bins = edges[1:-1]
    return np.digitize(x, bins, right=False)

def te_from_arrays(x, y, y_next, kx, ky):
    N = len(x)
    if N <= 0:
        return np.nan
    ids = (y_next.astype(np.int64) * (ky*kx) + y.astype(np.int64)*kx + x.astype(np.int64))
    counts = np.bincount(ids, minlength=ky*ky*kx).astype(np.float64)
    counts_xyz = counts.reshape(ky, ky, kx)
    counts_yx = counts_xyz.sum(axis=0)       # ky,kx
    counts_y_next_y = counts_xyz.sum(axis=2) # ky,ky
    counts_y = counts_yx.sum(axis=1)         # ky

    te = 0.0
    nz = np.nonzero(counts_xyz)
    for yn, y0, x0 in zip(*nz):
        c = counts_xyz[yn,y0,x0]
        p_xyz = c / N
        p_yx  = counts_yx[y0,x0] / N
        p_yNy = counts_y_next_y[yn,y0] / N
        p_y   = counts_y[y0] / N
        if p_yx <= 0 or p_yNy <= 0 or p_y <= 0:
            continue
        ratio = (p_xyz/p_yx) / (p_yNy/p_y)
        if ratio > 0:
            te += p_xyz * math.log(ratio, 2)
    return te

def te_discrete(x_disc, y_disc, macro, m, lag):
    """
    TE(X_{t-lag} -> Y_{t+1} | Y_t) within macrostate m.

    Valid i satisfy:
      i+1 < n, i-lag >= 0,
      macro[i] == m, macro[i+1] == m, and if lag>0 macro[i-lag] == m.
    """
    n = len(macro)
    idx = np.arange(lag, n-1)
    mask = (macro[idx] == m) & (macro[idx+1] == m)
    if lag > 0:
        mask &= (macro[idx-lag] == m)
    valid = idx[mask]
    if len(valid) == 0:
        return np.nan, 0
    x = x_disc[valid - lag]
    y = y_disc[valid]
    y_next = y_disc[valid + 1]
    kx = int(np.max(x_disc)) + 1
    ky = int(np.max(y_disc)) + 1
    return te_from_arrays(x,y,y_next,kx,ky), len(valid)

def summarize_lead_times(episodes_df, tick_df):
    # map tick->episode id
    ep = episodes_df.sort_values('idx_start').reset_index(drop=True)
    ep_id = np.full(len(tick_df), -1, dtype=int)
    for i,row in ep.iterrows():
        s,e = int(row['idx_start']), int(row['idx_end'])
        ep_id[s:e+1] = i

    say_idx = np.where(tick_df['did_say'].values.astype(int) == 1)[0]
    in_ep = ep_id[say_idx] >= 0
    say_in = say_idx[in_ep]
    ep_for_say = ep_id[say_in]
    ep_starts = ep.loc[ep_for_say,'idx_start'].astype(int).values
    lead_ticks = say_in - ep_starts

    per_ep_rows = []
    for i,row in ep.iterrows():
        s,e = int(row['idx_start']), int(row['idx_end'])
        say_here = np.where((tick_df.index.values>=s)&(tick_df.index.values<=e)&(tick_df['did_say'].values.astype(int)==1))[0]
        if len(say_here)==0:
            first,last,n_say = np.nan,np.nan,0
        else:
            first = int(say_here.min()) - s
            last  = int(say_here.max()) - s
            n_say = len(say_here)
        per_ep_rows.append({
            'episode_id': i,
            'idx_start': s,
            'idx_end': e,
            'len_ticks': e-s+1,
            'n_say': n_say,
            'first_say_lead': first,
            'last_say_lead': last,
            't_start': int(row.get('t_start', np.nan)),
            't_end': int(row.get('t_end', np.nan)),
            'mean_coherence': float(row.get('mean_coherence', np.nan)),
            'max_coherence': float(row.get('max_coherence', np.nan)),
        })
    per_ep = pd.DataFrame(per_ep_rows)

    per_say = pd.DataFrame({
        'say_tick_idx': say_in.astype(int),
        'say_t': tick_df.loc[say_in, 't'].astype(int).values,
        'episode_id': ep_for_say.astype(int),
        'episode_start_idx': ep_starts.astype(int),
        'episode_start_t': tick_df.loc[ep_starts, 't'].astype(int).values,
        'lead_ticks': lead_ticks.astype(int),
        'macrostate': tick_df.loc[say_in, 'macrostate'].astype(int).values,
        'has_input': tick_df.loc[say_in, 'has_input'].astype(int).values,
    })
    return per_ep, per_say

def plot_cdf(data_dict, title, xlabel, outpath):
    plt.figure(figsize=(6,4))
    for label, arr in data_dict.items():
        arr=np.asarray(arr, dtype=float)
        arr=arr[~np.isnan(arr)]
        arr=np.sort(arr)
        if len(arr)==0:
            continue
        y=np.arange(1,len(arr)+1)/len(arr)
        plt.step(arr, y, where='post', label=label)
    plt.xlabel(xlabel)
    plt.ylabel("CDF")
    plt.title(title)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(outpath)
    plt.close()

def plot_hist(data_dict, title, xlabel, outpath, bins=30):
    plt.figure(figsize=(6,4))
    for label, arr in data_dict.items():
        arr=np.asarray(arr, dtype=float)
        arr=arr[~np.isnan(arr)]
        plt.hist(arr, bins=bins, alpha=0.5, label=label)
    plt.xlabel(xlabel)
    plt.ylabel("count")
    plt.title(title)
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(outpath)
    plt.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tick_table", type=str, default="inputs/tick_table_1k.csv.gz")
    ap.add_argument("--episodes_balanced", type=str, default="inputs/comm_detector_balanced_thr4_rad50_episodes.csv")
    ap.add_argument("--episodes_conservative", type=str, default="inputs/comm_detector_conservative_thr5_rad50_episodes.csv")
    ap.add_argument("--outdir", type=str, default=".")
    ap.add_argument("--max_lag", type=int, default=10)
    args = ap.parse_args()

    outdir = Path(args.outdir)
    (outdir/"tables").mkdir(parents=True, exist_ok=True)
    (outdir/"figures").mkdir(parents=True, exist_ok=True)

    # Load data
    tick_df = pd.read_csv(args.tick_table, compression="gzip")
    tick_df['did_say'] = tick_df['did_say'].astype(int)
    tick_df['has_input'] = tick_df['has_input'].astype(int)
    macro = tick_df['macrostate'].astype(int).values

    ep_bal = pd.read_csv(args.episodes_balanced)
    ep_con = pd.read_csv(args.episodes_conservative)

    # Lead-time
    per_ep_bal, per_say_bal = summarize_lead_times(ep_bal, tick_df)
    per_ep_con, per_say_con = summarize_lead_times(ep_con, tick_df)

    per_ep_bal.to_csv(outdir/"tables/leadtime_balanced_per_episode.csv", index=False)
    per_say_bal.to_csv(outdir/"tables/leadtime_balanced_per_say.csv", index=False)
    per_ep_con.to_csv(outdir/"tables/leadtime_conservative_per_episode.csv", index=False)
    per_say_con.to_csv(outdir/"tables/leadtime_conservative_per_say.csv", index=False)

    plot_cdf({'balanced': per_ep_bal['first_say_lead'], 'conservative': per_ep_con['first_say_lead']},
             "Detector lead-time to FIRST did_say (per episode)", "ticks from detector onset",
             outdir/"figures/leadtime_first_say_cdf.png")
    plot_hist({'balanced': per_ep_bal['first_say_lead'], 'conservative': per_ep_con['first_say_lead']},
              "Detector lead-time to FIRST did_say (per episode)", "ticks from detector onset",
              outdir/"figures/leadtime_first_say_hist.png", bins=30)
    plot_cdf({'balanced': per_say_bal['lead_ticks'], 'conservative': per_say_con['lead_ticks']},
             "Detector lead-time for ALL did_say inside episodes", "ticks from detector onset",
             outdir/"figures/leadtime_all_says_cdf.png")
    plot_hist({'balanced': per_say_bal['lead_ticks'], 'conservative': per_say_con['lead_ticks']},
              "Detector lead-time for ALL did_say inside episodes", "ticks from detector onset",
              outdir/"figures/leadtime_all_says_hist.png", bins=40)

    # Macrostate-conditioned TE
    vars_cont = ['sie_v2_reward_mean','connectome_entropy','vt_coverage','reconfig_score','ute_text_count','b1_z']
    edges_map = {v: quantile_edges(tick_df[v].values, n_bins=8) for v in vars_cont}
    disc_map = {v: discretize_with_edges(tick_df[v].values, edges_map[v]) for v in vars_cont}

    # TE targets for the question
    pairs = [
        ('sie_v2_reward_mean','vt_coverage'),
        ('connectome_entropy','vt_coverage'),
        ('sie_v2_reward_mean','reconfig_score'),
        ('connectome_entropy','reconfig_score'),
        ('sie_v2_reward_mean','b1_z'),
        ('connectome_entropy','b1_z'),

        # reverse directions needed for drive indices
        ('vt_coverage','sie_v2_reward_mean'),
        ('vt_coverage','connectome_entropy'),
        ('reconfig_score','sie_v2_reward_mean'),
        ('reconfig_score','connectome_entropy'),
        ('b1_z','sie_v2_reward_mean'),
        ('b1_z','connectome_entropy'),
    ]

    rows=[]
    for m in sorted(np.unique(macro)):
        m=int(m)
        for (xv,yv) in pairs:
            x_disc = disc_map[xv]
            y_disc = disc_map[yv]
            for lag in range(args.max_lag+1):
                te, n_pairs = te_discrete(x_disc,y_disc,macro,m,lag)
                rows.append({'macrostate':m,'x':xv,'y':yv,'lag':lag,'te_bits':te,'n_pairs':n_pairs})
    te_df = pd.DataFrame(rows)
    te_df.to_csv(outdir/"tables/macrostate_te_lag_sweep_key_pairs.csv", index=False)

    # Summaries: lag0 and best lag
    summ=[]
    for (m,x,y),g in te_df.groupby(['macrostate','x','y']):
        g2=g.dropna(subset=['te_bits'])
        if len(g2)==0:
            continue
        te0=float(g2.loc[g2['lag']==0,'te_bits'].iloc[0]) if (g2['lag']==0).any() else np.nan
        n0=int(g2.loc[g2['lag']==0,'n_pairs'].iloc[0]) if (g2['lag']==0).any() else 0
        best=g2.loc[g2['te_bits'].idxmax()]
        summ.append({'macrostate':m,'x':x,'y':y,'te_lag0':te0,'n_pairs_lag0':n0,
                     'te_best':float(best['te_bits']),'lag_best':int(best['lag']),'n_pairs_best':int(best['n_pairs'])})
    te_summary = pd.DataFrame(summ)
    te_summary.to_csv(outdir/"tables/macrostate_te_summary_lag0_and_best.csv", index=False)

    # Drive indices at lag0 (dir-corrected)
    def te0(m,x,y):
        r = te_summary[(te_summary.macrostate==m)&(te_summary.x==x)&(te_summary.y==y)]
        return float(r.te_lag0.iloc[0]) if len(r) else np.nan

    drive=[]
    for m in sorted(np.unique(macro)):
        m=int(m)
        net_reward_cov = te0(m,'sie_v2_reward_mean','vt_coverage') - te0(m,'vt_coverage','sie_v2_reward_mean')
        net_entropy_cov = te0(m,'connectome_entropy','vt_coverage') - te0(m,'vt_coverage','connectome_entropy')
        goal_drive = net_reward_cov - net_entropy_cov

        net_reward_rec = te0(m,'sie_v2_reward_mean','reconfig_score') - te0(m,'reconfig_score','sie_v2_reward_mean')
        net_entropy_rec = te0(m,'connectome_entropy','reconfig_score') - te0(m,'reconfig_score','connectome_entropy')
        reset_drive = net_entropy_rec - net_reward_rec

        net_reward_b1z = te0(m,'sie_v2_reward_mean','b1_z') - te0(m,'b1_z','sie_v2_reward_mean')
        net_entropy_b1z = te0(m,'connectome_entropy','b1_z') - te0(m,'b1_z','connectome_entropy')
        boundary_drive = net_entropy_b1z - net_reward_b1z

        drive.append({
            'macrostate':m,
            'net_reward_drive_to_coverage':net_reward_cov,
            'net_entropy_drive_to_coverage':net_entropy_cov,
            'goal_drive_index_coverage':goal_drive,
            'net_reward_drive_to_reconfig_score':net_reward_rec,
            'net_entropy_drive_to_reconfig_score':net_entropy_rec,
            'reset_drive_index_reconfig_score':reset_drive,
            'net_reward_drive_to_b1_z':net_reward_b1z,
            'net_entropy_drive_to_b1_z':net_entropy_b1z,
            'boundary_drive_index_b1_z':boundary_drive,
        })
    drive_df = pd.DataFrame(drive)
    drive_df.to_csv(outdir/"tables/macrostate_goal_entropy_drive_indices.csv", index=False)

    # A few plots
    # lag sweep plots for reward/entropy -> coverage
    for m in sorted(np.unique(macro)):
        m=int(m)
        plt.figure(figsize=(6,4))
        for (xv,yv) in [('sie_v2_reward_mean','vt_coverage'),('connectome_entropy','vt_coverage')]:
            g = te_df[(te_df.macrostate==m)&(te_df.x==xv)&(te_df.y==yv)].sort_values('lag')
            plt.plot(g['lag'], g['te_bits'], marker='o', label=f"{xv}→{yv}")
        plt.xlabel("lag (ticks)")
        plt.ylabel("TE (bits)")
        plt.title(f"TE lag sweep: drivers→coverage (macrostate {m})")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(outdir/f"figures/te_lag_cov_macro{m}.png")
        plt.close()

    print("Done. Wrote tables/ and figures/ to", outdir.resolve())

if __name__ == "__main__":
    main()
