# VDM transition + comm-window analysis (scalar telemetry)

This bundle contains **reproducible** analyses on the 1k-neuron run tick table.

## Contents

- `inputs/`
  - `tick_table_1k.csv.gz` — unified tick table (macrostate labels + scalar telemetry + did_say/has_input)
  - `consciousness_proxy_window_metrics.csv` — window metrics used to derive `coherence_score`
- `tables/`
  - `transition_type_summary.csv`
  - `transition_event_stats.csv`
  - `comm_detector_*_episodes.csv`
  - `comm_detector_eval_summary.csv`
  - detector threshold sweeps
- `figures/`
  - `eta_*` and overlays
  - `*_episode_*_context.png` (comm-window examples)
- `scripts/`
  - `transition_eta.py`
  - `comm_window_detector.py`
  - `compare_scale_free_ab_template.py` (A/B template for Telegraph vs baseline)
- `params.json` — key parameters used for this run of analysis

## Reproduce (from this folder)

```bash
python scripts/transition_eta.py --tick_table inputs/tick_table_1k.csv.gz --out_dir .
python scripts/comm_window_detector.py --tick_table inputs/tick_table_1k.csv.gz \
  --coherence_windows inputs/consciousness_proxy_window_metrics.csv --out_dir .
```

## Notes

- The comm-window detector is intentionally **scalar-only**: it is designed to help you time *future* transduction experiments even before locality logging exists.
- The A/B template is provided because **Telegraph-Fisher effects on degree heavy-tails and Gini cannot be inferred from the baseline run alone**; it needs at least one matched run with Telegraph enabled.
