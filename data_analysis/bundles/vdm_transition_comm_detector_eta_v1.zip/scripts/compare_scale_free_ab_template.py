#!/usr/bin/env python3
"""
Template: A/B compare the degree heavy-tail + Gini metrics between two runs
(e.g., baseline vs Telegraph-Fisher update).

This *does not* run simulations. It expects each run directory to already contain:
- a connectome snapshot edge list (or adjacency) for the same sampling moment, OR
- a precomputed degree list.

Drop in your own loader logic inside `load_degrees(...)`.

Outputs:
- tables/ab_degree_summary.csv
- figures/ab_degree_ccdf.png
- figures/ab_degree_hist.png
"""
import argparse, pathlib, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def gini(x):
    x=np.asarray(x, dtype=float)
    if np.all(x==0): return 0.0
    x=np.sort(x)
    n=len(x)
    cum=np.cumsum(x)
    return (n+1 - 2*np.sum(cum)/cum[-1]) / n

def load_degrees(run_dir: pathlib.Path):
    """
    TODO: implement: load degree sequence from your artifacts.
    Current stub: looks for 'degree_list.json' or 'degrees.csv' in run_dir.
    """
    p_json = run_dir/"degree_list.json"
    p_csv  = run_dir/"degrees.csv"
    if p_json.exists():
        return np.array(json.loads(p_json.read_text()))
    if p_csv.exists():
        return pd.read_csv(p_csv)["degree"].to_numpy()
    raise FileNotFoundError(f"Provide degrees.csv or degree_list.json in {run_dir}")

def ccdf(deg):
    deg=np.asarray(deg)
    xs=np.sort(np.unique(deg))
    cc=np.array([(deg>=x).mean() for x in xs])
    return xs, cc

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--run_a", required=True)
    ap.add_argument("--run_b", required=True)
    ap.add_argument("--label_a", default="baseline")
    ap.add_argument("--label_b", default="telegraph")
    ap.add_argument("--out_dir", default=".")
    args=ap.parse_args()

    out_dir=pathlib.Path(args.out_dir)
    (out_dir/"tables").mkdir(parents=True, exist_ok=True)
    (out_dir/"figures").mkdir(parents=True, exist_ok=True)

    deg_a=load_degrees(pathlib.Path(args.run_a))
    deg_b=load_degrees(pathlib.Path(args.run_b))

    summ = pd.DataFrame([
        {"run":args.label_a, "n":len(deg_a), "deg_mean":deg_a.mean(), "deg_med":np.median(deg_a), "deg_max":deg_a.max(), "gini":gini(deg_a)},
        {"run":args.label_b, "n":len(deg_b), "deg_mean":deg_b.mean(), "deg_med":np.median(deg_b), "deg_max":deg_b.max(), "gini":gini(deg_b)},
    ])
    summ.to_csv(out_dir/"tables/ab_degree_summary.csv", index=False)

    # CCDF plot
    fig, ax = plt.subplots(figsize=(8,5))
    xa, ya = ccdf(deg_a); xb, yb = ccdf(deg_b)
    ax.loglog(xa, ya, marker="o", linestyle="-", label=args.label_a)
    ax.loglog(xb, yb, marker="o", linestyle="-", label=args.label_b)
    ax.set_xlabel("degree k")
    ax.set_ylabel("P(K ≥ k)")
    ax.set_title("Degree CCDF (A/B)")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir/"figures/ab_degree_ccdf.png", dpi=160)
    plt.close(fig)

    # Histogram
    fig, ax = plt.subplots(figsize=(8,5))
    bins = np.logspace(np.log10(max(1, min(deg_a.min(), deg_b.min()))), np.log10(max(deg_a.max(), deg_b.max())), 30)
    ax.hist(deg_a, bins=bins, alpha=0.6, label=args.label_a)
    ax.hist(deg_b, bins=bins, alpha=0.6, label=args.label_b)
    ax.set_xscale("log")
    ax.set_xlabel("degree k")
    ax.set_ylabel("count")
    ax.set_title("Degree histogram (log bins)")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_dir/"figures/ab_degree_hist.png", dpi=160)
    plt.close(fig)

if __name__ == "__main__":
    main()
