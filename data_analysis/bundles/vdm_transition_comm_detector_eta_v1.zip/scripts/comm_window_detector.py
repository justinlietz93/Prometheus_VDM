#!/usr/bin/env python3
"""
VDM: Communication-window detector from scalar telemetry

Implements:
  attempts_to_communicate(t) := (macrostate==1) AND (coherence high) AND (near boundary markers)

Boundary markers (scalar-only):
  transition_tick OR b1_spike OR reconfig_spike

Coherence:
  uses inputs/consciousness_proxy_window_metrics.csv (window-level coherence_score),
  then assigns per-tick coherence as max coherence among windows covering that tick.

Outputs:
- tables/comm_detector_*_episodes.csv
- tables/comm_detector_eval_summary.csv
- figures/*_episode_*_context.png
- tables/comm_detector_threshold_sweep_*.csv
"""
import argparse, pathlib, gzip
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def dilate_bool(arr, radius):
    if radius<=0:
        return arr.copy()
    n=len(arr)
    out=np.zeros(n, dtype=bool)
    idx=np.where(arr)[0]
    for i in idx:
        s=max(0, i-radius); e=min(n, i+radius+1)
        out[s:e]=True
    return out

def build_episodes(flag, min_len=5, gap_max=5):
    idx=np.where(flag)[0]
    if len(idx)==0: return []
    segs=[]
    start=idx[0]; prev=idx[0]
    for i in idx[1:]:
        if i==prev+1:
            prev=i
        else:
            segs.append([start, prev])
            start=i; prev=i
    segs.append([start, prev])
    # merge
    merged=[segs[0]]
    for s,e in segs[1:]:
        last=merged[-1]
        if s - last[1] - 1 <= gap_max:
            last[1]=e
        else:
            merged.append([s,e])
    segs=merged
    return [(s,e) for s,e in segs if (e-s+1)>=min_len]

def episode_table(df, flag, name):
    eps=build_episodes(flag)
    rows=[]
    for k,(s,e) in enumerate(eps):
        sl=df.iloc[s:e+1]
        rows.append({
            "detector":name,
            "episode_id":k,
            "idx_start":s, "idx_end":e,
            "t_start":int(sl["t"].iloc[0]), "t_end":int(sl["t"].iloc[-1]),
            "len_ticks":int(e-s+1),
            "mean_coherence":float(sl["coherence_score"].mean()),
            "max_coherence":float(sl["coherence_score"].max()),
            "macro_mode":int(sl["macrostate"].mode().iloc[0]),
            "input_rate":float(sl["has_input"].mean()),
            "say_count":int(sl["did_say"].sum()),
            "b1_spike_count":int(sl["b1_spike"].sum()),
            "reconfig_spike_count":int(sl["reconfig_spike"].sum()),
            "transition_count":int(sl["transition"].sum()),
        })
    return pd.DataFrame(rows)

def eval_episode_detector(df, ep_df):
    if ep_df.empty:
        return {"n_episodes":0}
    did_say=df["did_say"].to_numpy().astype(bool)
    macro=df["macrostate"].to_numpy()
    say_idx=np.where(did_say & (macro==1))[0]
    eps=[(r.idx_start, r.idx_end) for r in ep_df.itertuples(index=False)]
    captured=0
    for i in say_idx:
        for s,e in eps:
            if s<=i<=e:
                captured += 1
                break
    recall=captured/len(say_idx) if len(say_idx)>0 else np.nan
    ep_has=0
    for s,e in eps:
        if (did_say[s:e+1] & (macro[s:e+1]==1)).any():
            ep_has += 1
    precision=ep_has/len(eps)
    duty=sum(e-s+1 for s,e in eps)/len(df)
    return {
        "n_episodes":len(eps),
        "episode_precision":precision,
        "say_recall_within_episodes":recall,
        "duty_cycle_episode":duty,
        "avg_len":np.mean([e-s+1 for s,e in eps]),
    }

def plot_episode_context(df, row, fig_path, pad=300):
    s=row["idx_start"]; e=row["idx_end"]
    s0=max(0,s-pad); e0=min(len(df)-1,e+pad)
    sl=df.iloc[s0:e0+1]
    x=sl["t"].to_numpy()

    fig, axes = plt.subplots(3,1, figsize=(12,8), sharex=True)

    axes[0].plot(x, sl["macrostate"], label="macrostate")
    axes[0].plot(x, sl["has_input"]*0.2 + sl["macrostate"].min()-0.2, label="has_input (scaled)")
    axes[0].axvspan(df["t"].iloc[s], df["t"].iloc[e], alpha=0.2)
    axes[0].set_ylabel("macro/input"); axes[0].legend(fontsize=8); axes[0].grid(True, alpha=0.3)

    axes[1].plot(x, sl["coherence_score"], label="coherence_score")
    axes[1].plot(x, sl["b1_z"], label="b1_z")
    axes[1].axvspan(df["t"].iloc[s], df["t"].iloc[e], alpha=0.2)
    axes[1].set_ylabel("coh/b1_z"); axes[1].legend(fontsize=8); axes[1].grid(True, alpha=0.3)

    axes[2].plot(x, sl["reconfig_score"], label="reconfig_score")
    say_x = sl.loc[sl["did_say"]==1,"t"]
    axes[2].scatter(say_x, np.full_like(say_x, sl["reconfig_score"].max()), label="did_say", marker="o")
    b1_x = sl.loc[sl["b1_spike"]==1,"t"]
    axes[2].scatter(b1_x, np.full_like(b1_x, sl["reconfig_score"].max()*0.95), label="b1_spike", marker="x")
    r_x = sl.loc[sl["reconfig_spike"]==1,"t"]
    axes[2].scatter(r_x, np.full_like(r_x, sl["reconfig_score"].max()*0.9), label="reconfig_spike", marker="^")
    axes[2].axvspan(df["t"].iloc[s], df["t"].iloc[e], alpha=0.2)
    axes[2].set_ylabel("reconfig/marks"); axes[2].legend(fontsize=8, ncol=3); axes[2].grid(True, alpha=0.3)
    axes[2].set_xlabel("t (tick id)")

    fig.suptitle(f"Comm-window episode #{row['episode_id']} t=[{df['t'].iloc[s]}..{df['t'].iloc[e]}] say={row['say_count']}")
    fig.tight_layout(rect=[0,0,1,0.95])
    fig.savefig(fig_path, dpi=160)
    plt.close(fig)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--tick_table", default="inputs/tick_table_1k.csv.gz")
    ap.add_argument("--coherence_windows", default="inputs/consciousness_proxy_window_metrics.csv")
    ap.add_argument("--out_dir", default=".")
    ap.add_argument("--coh_thr_bal", type=float, default=4.0)
    ap.add_argument("--coh_thr_cons", type=float, default=5.0)
    ap.add_argument("--boundary_rad", type=int, default=50)
    args=ap.parse_args()

    out_dir=pathlib.Path(args.out_dir)
    fig_dir=out_dir/"figures"; fig_dir.mkdir(parents=True, exist_ok=True)
    tab_dir=out_dir/"tables"; tab_dir.mkdir(parents=True, exist_ok=True)

    with gzip.open(args.tick_table,"rt") as f:
        df=pd.read_csv(f)
    coh=pd.read_csv(args.coherence_windows)

    # Build per-tick coherence as max over windows covering tick
    n=len(df)
    coh_tick=np.full(n, np.nan)
    for _,r in coh.iterrows():
        s=int(r["idx_start"]); e=int(r["idx_end"])
        v=float(r["coherence_score"])
        cur=coh_tick[s:e+1]
        m=np.isnan(cur) | (v>cur)
        cur[m]=v
        coh_tick[s:e+1]=cur
    coh_tick[np.isnan(coh_tick)] = np.nanmin(coh_tick)
    df["coherence_score"]=coh_tick

    # Boundary markers and dilation
    boundary_base = df["transition"].to_numpy().astype(bool) | df["b1_spike"].to_numpy().astype(bool) | df["reconfig_spike"].to_numpy().astype(bool)
    boundary = dilate_bool(boundary_base, args.boundary_rad)

    macro = df["macrostate"].to_numpy()
    coh_arr = df["coherence_score"].to_numpy()

    def run_detector(name, coh_thr):
        flag = (macro==1) & (coh_arr>=coh_thr) & boundary
        ep = episode_table(df, flag, name)
        ep.to_csv(tab_dir/f"comm_detector_{name}_episodes.csv", index=False)
        # plot top episodes by say_count
        if not ep.empty:
            top = ep.sort_values("say_count", ascending=False).head(5)
            for _,row in top.iterrows():
                plot_episode_context(df, row, fig_dir/f"{name}_episode_{int(row['episode_id']):02d}_context.png")
        return ep

    ep_bal = run_detector("balanced_thr4_rad50", args.coh_thr_bal)
    ep_cons = run_detector("conservative_thr5_rad50", args.coh_thr_cons)

    # Evaluation summary (macrostate-1 say events)
    eval_rows=[]
    for name, ep in [("balanced_thr4_rad50", ep_bal), ("conservative_thr5_rad50", ep_cons)]:
        ev = eval_episode_detector(df, ep)
        ev["detector"]=name
        eval_rows.append(ev)
    pd.DataFrame(eval_rows).to_csv(tab_dir/"comm_detector_eval_summary.csv", index=False)

if __name__ == "__main__":
    main()
