#!/usr/bin/env python3
"""
VDM: Macrostate-transition event-triggered averages (ETAs)

Inputs
------
- inputs/tick_table_1k.csv.gz
  Must include columns:
    idx implicit row index (0..N-1), t (tick id), macrostate, transition (bool),
    vt_coverage, vt_entropy, connectome_entropy, active_edges,
    b1_z, b1_spike, reconfig_score, reconfig_spike, sie_total_reward, sie_valence_01,
    has_input, did_say

Outputs
-------
- tables/transition_type_summary.csv
- tables/transition_event_stats.csv
- figures/eta_*  (per-transition ETAs)
- figures/eta_overlay_has_input.png
- figures/eta_overlay_did_say.png
"""
import argparse, pathlib, gzip, io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def compute_eta(data_matrix, event_indices, W):
    lags = np.arange(-W, W+1)
    valid = [i for i in event_indices if i-W >= 0 and i+W < len(data_matrix)]
    if len(valid) == 0:
        return lags, None, None, 0
    slices = np.stack([data_matrix[i-W:i+W+1,:] for i in valid], axis=0)
    mean = np.nanmean(slices, axis=0)
    se = np.nanstd(slices, axis=0, ddof=1) / np.sqrt(len(valid))
    return lags, mean, se, len(valid)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tick_table", default="inputs/tick_table_1k.csv.gz")
    ap.add_argument("--out_dir", default=".")
    ap.add_argument("--W", type=int, default=250)
    args = ap.parse_args()

    out_dir = pathlib.Path(args.out_dir)
    fig_dir = out_dir/"figures"; fig_dir.mkdir(parents=True, exist_ok=True)
    tab_dir = out_dir/"tables"; tab_dir.mkdir(parents=True, exist_ok=True)

    # Load tick table
    with gzip.open(args.tick_table, "rt") as f:
        df = pd.read_csv(f)

    # Transition events
    df["macro_prev"] = df["macrostate"].shift(1)
    df["transition"] = (df["macrostate"] != df["macro_prev"]) & df["macro_prev"].notna()
    transitions = df[df["transition"]].copy()
    transitions["from"] = transitions["macro_prev"].astype(int)
    transitions["to"] = transitions["macrostate"].astype(int)
    transitions["trans_type"] = transitions["from"].astype(str) + "->" + transitions["to"].astype(str)

    metrics_cont = ["vt_coverage","vt_entropy","connectome_entropy","active_edges","b1_z","reconfig_score","sie_total_reward","sie_valence_01"]
    metrics_bin  = ["has_input","did_say","b1_spike","reconfig_spike"]
    all_metrics  = metrics_cont + metrics_bin

    data_matrix = df[all_metrics].to_numpy()
    W = args.W
    lags = np.arange(-W, W+1)

    # Compute ETAs
    eta = {}
    for tt, g in transitions.groupby("trans_type"):
        idxs = g.index.to_list()
        lags, mean, se, n = compute_eta(data_matrix, idxs, W)
        eta[tt] = dict(n=n, mean=mean, se=se)

    # Save summary tables (pre/post deltas + lag0)
    def summarize(tt, pre=(-50,-1), post=(1,50), horizon=50):
        info = eta[tt]
        if info["mean"] is None:
            return None
        mean = info["mean"]
        def mask(win): return (lags>=win[0]) & (lags<=win[1])
        pre_m = mask(pre); post_m = mask(post); h_m = (lags>=1) & (lags<=horizon)
        out = {"trans_type":tt, "n_events":info["n"]}
        for m in metrics_cont:
            j = all_metrics.index(m)
            out[f"{m}_pre"] = mean[pre_m,j].mean()
            out[f"{m}_post"] = mean[post_m,j].mean()
            out[f"{m}_delta"] = out[f"{m}_post"] - out[f"{m}_pre"]
        for m in metrics_bin:
            j = all_metrics.index(m)
            out[f"{m}_pre_rate"] = mean[pre_m,j].mean()
            out[f"{m}_post_rate"] = mean[post_m,j].mean()
            out[f"{m}_delta"] = out[f"{m}_post_rate"] - out[f"{m}_pre_rate"]
        out[f"did_say_h{horizon}_rate"] = mean[h_m, all_metrics.index("did_say")].mean()
        # lag0
        idx0 = np.where(lags==0)[0][0]
        for m in ["did_say","b1_spike","reconfig_spike","has_input","b1_z","reconfig_score"]:
            out[f"{m}_lag0"] = mean[idx0, all_metrics.index(m)]
        return out

    rows=[]
    for tt in sorted(eta.keys()):
        s = summarize(tt)
        if s: rows.append(s)
    pd.DataFrame(rows).to_csv(tab_dir/"transition_type_summary.csv", index=False)

    # Event-level stats (input boundary + say-within-horizon)
    df["input_prev"] = df["has_input"].shift(1)
    df["input_change"] = (df["has_input"] != df["input_prev"]) & df["input_prev"].notna()
    did_say = df["did_say"].to_numpy().astype(bool)
    macro = df["macrostate"].to_numpy()
    H = 50
    def any_say(i):
        j0=i+1; j1=min(len(did_say), i+H+1)
        return 1 if did_say[j0:j1].any() else 0
    ev = transitions[["t","from","to","trans_type"]].copy()
    ev["idx"]=ev.index
    ev["input_change"] = df.loc[ev["idx"],"input_change"].values
    ev["has_input_t"] = df.loc[ev["idx"],"has_input"].values
    ev["did_say_t"] = df.loc[ev["idx"],"did_say"].values
    ev["b1_spike_t"] = df.loc[ev["idx"],"b1_spike"].values
    ev["reconfig_spike_t"] = df.loc[ev["idx"],"reconfig_spike"].values
    ev["say_within50"] = [any_say(i) for i in ev["idx"]]
    ev.groupby("trans_type").agg(
        n=("idx","size"),
        input_present_rate=("has_input_t","mean"),
        input_change_rate=("input_change","mean"),
        say_at_transition_rate=("did_say_t","mean"),
        say_within50_rate=("say_within50","mean"),
        b1_at_transition_rate=("b1_spike_t","mean"),
        reconfig_at_transition_rate=("reconfig_spike_t","mean"),
    ).reset_index().sort_values("n", ascending=False).to_csv(tab_dir/"transition_event_stats.csv", index=False)

    # Plot ETAs per main transition type
    main_types = [tt for tt, c in transitions["trans_type"].value_counts().items() if c>=18]
    for tt in main_types:
        info=eta[tt]
        mean, se, n = info["mean"], info["se"], info["n"]
        if mean is None: 
            continue

        # continuous
        fig, ax = plt.subplots(figsize=(10,5))
        for m in ["connectome_entropy","active_edges","vt_coverage","reconfig_score","b1_z"]:
            j = all_metrics.index(m)
            ax.plot(lags, mean[:,j], label=m)
            ax.fill_between(lags, mean[:,j]-1.96*se[:,j], mean[:,j]+1.96*se[:,j], alpha=0.2)
        ax.axvline(0, color="k", alpha=0.6)
        ax.set_title(f"ETA: {tt} (n={n}) — continuous")
        ax.set_xlabel("lag (ticks)"); ax.set_ylabel("value")
        ax.grid(True, alpha=0.3); ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(fig_dir/f"eta_{tt}_continuous.png", dpi=160)
        plt.close(fig)

        # binary
        fig, ax = plt.subplots(figsize=(10,5))
        for m in ["has_input","did_say","b1_spike","reconfig_spike"]:
            j = all_metrics.index(m)
            ax.plot(lags, mean[:,j], label=m)
            ax.fill_between(lags, mean[:,j]-1.96*se[:,j], mean[:,j]+1.96*se[:,j], alpha=0.2)
        ax.axvline(0, color="k", alpha=0.6)
        ax.set_title(f"ETA: {tt} (n={n}) — binary")
        ax.set_xlabel("lag (ticks)"); ax.set_ylabel("rate")
        ax.grid(True, alpha=0.3); ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(fig_dir/f"eta_{tt}_binary.png", dpi=160)
        plt.close(fig)

    # Overlay plots (has_input / did_say)
    def overlay(metric):
        fig, ax = plt.subplots(figsize=(10,5))
        for tt in main_types:
            info=eta[tt]
            if info["mean"] is None: continue
            ax.plot(lags, info["mean"][:, all_metrics.index(metric)], label=f"{tt} (n={info['n']})")
        ax.axvline(0, color="k", alpha=0.6)
        ax.set_title(f"ETA overlay: {metric}")
        ax.set_xlabel("lag (ticks)"); ax.set_ylabel(metric)
        ax.grid(True, alpha=0.3); ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(fig_dir/f"eta_overlay_{metric}.png", dpi=160)
        plt.close(fig)

    overlay("has_input")
    overlay("did_say")

if __name__ == "__main__":
    main()
