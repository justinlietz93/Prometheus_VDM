# VDM four-proofs pack (full-run, snapshot-grounded)

This pack runs the four analyses you specified (Dynamic Core / Criticality / Thermodynamic Bistability / Information-Geometry Speed) using:

- **Full snapshot series**: `snapshots_backup.zip` (485 snapshots; ticks 60..29160, every 60 ticks)
- **Scalar telemetry slices** (for PSD/avalanches only): `20260204_142311.zip` (t=0..8247), `20260204_144053.zip` (t=8264..16504), `events.jsonl.zip` (t=24910..29176)

## Important constraint (why “full runtime” = two resolutions)
You *did* provide the full run structurally (all H5 snapshots). That supports full-run geometry/topology analyses.

For **per-tick scalar telemetry**, the data in this environment covers **three tick spans** and contains a gap (t=16505..24909). PSD/avalanche results are therefore reported per-slice, not for the missing span.

Also: the `utd_events.zip/jsonl` currently present here appears to correspond to a different run (file names inside `utd_events.zip` are `20251115_*`). This pack does not attempt to quote/interpret macro text outputs for the full run.

---

## Proof 1: Dynamic Core / rotating coalition (TRQA via hub occupancy recurrence)
Definition:
- For each snapshot, compute the **Top-20 out-degree hubs** (set of node IDs).
- Compute **Jaccard similarity** between hub sets for all snapshot pairs → recurrence plot.

Deliverables:
- `figures/fig1a_hub_jaccard_heatmap.png` (real-valued recurrence)
- `figures/fig1b_hub_recurrence_binary_theta0p2.png` (thresholded recurrence)
- `figures/fig1c_hub_recurrence_vs_lag.png` (recurrence vs lag)

Quantification:
- `tables/rqa_metrics_by_threshold.csv` reports RR/DET/LAM for thresholds 0.15..0.30.

Interpretation target for paper:
- Block-diagonal structure = metastable “coalitions”
- Off-diagonal bright returns = recurrence / revisiting prior configurations

---

## Proof 2: Criticality-adjacent dynamics (PSD + avalanche scaling)
Using scalar telemetry (per-tick) for each available slice.

PSD:
- `figures/fig2_psd_firing_var.png`
- `figures/fig2_psd_active_edges.png`
- `tables/psd_slopes.csv` contains fitted β in PSD ~ 1/f^β bands.

Avalanches:
- defined as contiguous runs where the activity proxy exceeds its 75th percentile.
- size = sum(excess above threshold), duration = number of ticks.

Deliverables:
- `figures/fig2b_avalanche_size_ccdf_mid.png`
- `figures/fig2c_avalanche_duration_ccdf_mid.png`
- `tables/avalanche_scaling.csv`

Interpretation target for paper:
- 1/f-like spectra and power-law-like avalanche distributions are consistent with “criticality-adjacent” behavior (not by themselves a proof of SOC, but a standard quantitative signature).

---

## Proof 3: Thermodynamic hypothesis (empirical free-energy landscape)
Order parameters from H5 snapshots:
- x = **density proxy** = nnz edges (CSR nnz)
- y = **hierarchy proxy** = Gini(out-degree)

Compute 2D probability (KDE), then:
- F(x,y) = -log P(x,y)

Deliverables:
- `figures/fig3_free_energy_landscape.png`
- `figures/fig3b_nnz_timeseries.png`
- `figures/fig3c_gini_timeseries.png`
- `figures/fig3d_order_params_scatter_by_input.png` (where input telemetry exists)

Wells/barrier:
- `tables/free_energy_wells.csv` (2-well centers from k-means in (x,y))
- `tables/free_energy_barrier_summary.json` (barrier height along line between wells)

---

## Proof 4: Information-geometry hypothesis (statistical speed)
Mass distribution source:
- **ADC territory masses** from each snapshot's `adc_json`.

Define P_t as the normalized vector over keys 0..4, then compute speed:
- v_t = Hellinger(P_t, P_{t-1})

Deliverables:
- `figures/fig4_fisher_speed_timeseries.png`
- `figures/fig4b_fisher_speed_by_epoch.png`
- `tables/adc_mass_distribution.csv`
- `tables/fisher_speed_hellinger.csv`
- `tables/fisher_speed_epoch_summary.csv`

---

## How to reproduce
Run:
- `scripts/run_four_proofs_fullrun.py`

Inputs expected (paths are hardcoded in script header; edit if needed):
- extracted snapshot directory: `_snapshots_backup_extracted/snapshots_backup/state_*.h5`
- events slices zips:
  - `20260204_142311.zip`
  - `20260204_144053.zip`
  - `events.jsonl.zip`

Outputs:
- same tables + figures as in this pack.

---
