#!/usr/bin/env python3
"""
Repro script: VDM four-proofs pack (snapshot-grounded)

Outputs:
- tables/*.csv
- figures/*.png

Notes:
- Uses H5 snapshots for proofs 1,3,4.
- Uses tick telemetry slices for proof 2.
"""
import os, re, json, zipfile, shutil, glob
import numpy as np
import pandas as pd
import h5py
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter
from scipy.stats import gaussian_kde
from sklearn.cluster import KMeans

OUTDIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TABLES = os.path.join(OUTDIR, "tables")
FIGS = os.path.join(OUTDIR, "figures")

# Inputs (edit if needed)
SNAP_ZIP = os.path.abspath(os.path.join(OUTDIR, "..", "snapshots_backup.zip"))
BEGIN_ZIP = os.path.abspath(os.path.join(OUTDIR, "..", "20260204_142311.zip"))
MID_ZIP   = os.path.abspath(os.path.join(OUTDIR, "..", "20260204_144053.zip"))
END_ZIP   = os.path.abspath(os.path.join(OUTDIR, "..", "events.jsonl.zip"))

EXTRACT_DIR = os.path.abspath(os.path.join(OUTDIR, "..", "_snapshots_backup_extracted"))

def ensure_dirs():
    os.makedirs(TABLES, exist_ok=True)
    os.makedirs(FIGS, exist_ok=True)
    os.makedirs(EXTRACT_DIR, exist_ok=True)

def extract_snapshots():
    # Extract only non-__MACOSX h5 members
    with zipfile.ZipFile(SNAP_ZIP, 'r') as z:
        members=[n for n in z.namelist() if n.startswith('snapshots_backup/') and n.endswith('.h5') and '__MACOSX' not in n]
        z.extractall(EXTRACT_DIR, members=members)
    return sorted(glob.glob(os.path.join(EXTRACT_DIR, "snapshots_backup", "state_*.h5")),
                  key=lambda p:int(re.search(r'state_(\d+)\.h5', os.path.basename(p)).group(1)))

def gini_coefficient(x):
    x = np.asarray(x, dtype=float).flatten()
    if np.all(x == 0):
        return 0.0
    x_sorted = np.sort(x)
    n = x_sorted.size
    cumx = np.cumsum(x_sorted)
    g = (n + 1 - 2 * np.sum(cumx) / cumx[-1]) / n
    return float(g)

def powerlaw_alpha_discrete_mle(deg, kmin):
    deg = np.asarray(deg)
    tail = deg[deg >= kmin]
    n = tail.size
    if n == 0:
        return np.nan, 0
    denom = np.sum(np.log(tail / (kmin - 0.5)))
    if denom <= 0:
        return np.nan, int(n)
    alpha = 1 + n / denom
    return float(alpha), int(n)

def hellinger(p,q):
    return float(np.sqrt(0.5*np.sum((np.sqrt(p)-np.sqrt(q))**2)))

def rqa_metrics(R, l_min=2, v_min=2, exclude_main_diag=True):
    R = (R>0).astype(np.uint8)
    N = R.shape[0]
    mask = np.ones_like(R, dtype=bool)
    if exclude_main_diag:
        np.fill_diagonal(mask, False)
    total_rec = int(R[mask].sum())
    RR = total_rec / mask.sum() if mask.sum()>0 else np.nan

    # diagonal lines
    diag_line_points = 0
    diag_lengths=[]
    for k in range(-(N-1), N):
        if k==0 and exclude_main_diag:
            continue
        diag = np.diag(R, k=k)
        run=0
        for val in diag:
            if val:
                run +=1
            else:
                if run>=l_min:
                    diag_lengths.append(run)
                    diag_line_points += run
                run=0
        if run>=l_min:
            diag_lengths.append(run)
            diag_line_points += run
    DET = diag_line_points / total_rec if total_rec>0 else np.nan

    # vertical lines
    vert_line_points=0
    vert_lengths=[]
    for j in range(N):
        col = R[:,j].copy()
        if exclude_main_diag:
            col[j]=0
        run=0
        for val in col:
            if val:
                run+=1
            else:
                if run>=v_min:
                    vert_lengths.append(run)
                    vert_line_points += run
                run=0
        if run>=v_min:
            vert_lengths.append(run)
            vert_line_points += run
    LAM = vert_line_points / total_rec if total_rec>0 else np.nan

    return {
        'RR':RR,'DET':DET,'LAM':LAM,
        'diag_line_count':len(diag_lengths),
        'diag_line_mean':float(np.mean(diag_lengths)) if diag_lengths else np.nan,
        'vert_line_count':len(vert_lengths),
        'vert_line_mean':float(np.mean(vert_lengths)) if vert_lengths else np.nan,
    }

def compute_psd(x):
    x=np.asarray(x,dtype=float)
    x=x-np.mean(x)
    n=len(x)
    freqs=np.fft.rfftfreq(n,d=1.0)
    psd=(np.abs(np.fft.rfft(x))**2)/n
    return freqs[1:], psd[1:]  # skip f=0

def psd_slope(series, fmin=1/500, fmax=0.2):
    freqs, psd = compute_psd(series)
    mask=(freqs>=fmin)&(freqs<=fmax)&(psd>0)
    if mask.sum()<10:
        return np.nan, np.nan, int(mask.sum())
    slope, intercept=np.polyfit(np.log10(freqs[mask]), np.log10(psd[mask]), 1)
    beta=-slope
    return float(beta), float(slope), int(mask.sum())

def compute_avalanches(series, thresh_quantile=0.75, size_mode='sum_excess'):
    x=np.asarray(series, dtype=float)
    thr=float(np.quantile(x, thresh_quantile))
    above=x>thr
    aval=[]
    i=0
    n=len(x)
    while i<n:
        if not above[i]:
            i+=1
            continue
        j=i
        while j<n and above[j]:
            j+=1
        seg=x[i:j]
        dur=j-i
        if size_mode=='sum_excess':
            size=float((seg - thr).sum())
        elif size_mode=='sum':
            size=float(seg.sum())
        else:
            size=float(dur)
        aval.append((dur,size))
        i=j
    return np.array(aval), thr

def fit_powerlaw_alpha_continuous(data, xmin):
    data=np.asarray(data)
    tail=data[data>=xmin]
    n=len(tail)
    if n<5:
        return np.nan, int(n)
    alpha=1 + n / np.sum(np.log(tail/xmin))
    return float(alpha), int(n)

def avalanche_scaling(series, q=0.75):
    aval,thr=compute_avalanches(series,q)
    if len(aval)==0:
        return None
    dur=aval[:,0]; size=aval[:,1]
    xmin_size=float(np.quantile(size,0.1))
    xmin_dur=float(np.quantile(dur,0.1))
    alpha_s,n_s=fit_powerlaw_alpha_continuous(size, xmin_size)
    alpha_d,n_d=fit_powerlaw_alpha_continuous(dur, xmin_dur)
    mask=(size>0)&(dur>0)
    gamma=np.nan
    if mask.sum()>10:
        gamma=float(np.polyfit(np.log(dur[mask]), np.log(size[mask]), 1)[0])
    return {
        'thr':float(thr),'n_aval':int(len(aval)),
        'xmin_size':xmin_size,'alpha_size':alpha_s,'n_tail_size':n_s,
        'xmin_dur':xmin_dur,'alpha_dur':alpha_d,'n_tail_dur':n_d,
        'gamma_size_dur':gamma
    }

def load_tick_series_from_zip(zip_path, member_hint="events.jsonl"):
    with zipfile.ZipFile(zip_path,'r') as z:
        member=None
        if member_hint in z.namelist():
            member=member_hint
        else:
            cand=[n for n in z.namelist() if n.endswith("events.jsonl")]
            if cand:
                member=cand[0]
        if member is None:
            raise FileNotFoundError(f"No events.jsonl in {zip_path}")

        rows=[]
        with z.open(member) as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    obj=json.loads(line)
                except Exception:
                    continue
                if obj.get("msg")!="tick":
                    continue
                rows.append({
                    't':obj.get('t'),
                    'active_edges':obj.get('active_edges'),
                    'active_synapses':obj.get('active_synapses'),
                    'firing_var':obj.get('firing_var'),
                    'ute_text_count':obj.get('ute_text_count'),
                    'ute_in_count':obj.get('ute_in_count'),
                })
    df=pd.DataFrame(rows)
    return df

def main():
    ensure_dirs()
    snap_files = extract_snapshots()

    # Snapshot metrics + hubs + ADC mass vectors
    metrics=[]
    hub_bits=[]
    mass_vecs=[]
    hub_k=20
    for fp in snap_files:
        t=int(re.search(r'state_(\d+)\.h5', os.path.basename(fp)).group(1))
        with h5py.File(fp,'r') as h5:
            sp=h5['sparse']
            row_ptr=sp['row_ptr'][:]
            col_idx=sp['col_idx'][:]
            W=sp['W'][:]
            nnz=int(col_idx.shape[0])
            out_deg=np.diff(row_ptr).astype(int)
            gini=gini_coefficient(out_deg)
            alpha13,n_tail13=powerlaw_alpha_discrete_mle(out_deg,13)
            hub_idx=np.argsort(out_deg)[-hub_k:]
            bit=0
            for i in hub_idx:
                bit |= 1<<int(i)
            hub_bits.append(bit)

            adc=json.loads(h5['adc_json'][()].decode('utf-8'))
            masses=np.zeros(5,dtype=float)
            for terr in adc.get('territories',[]):
                key=terr.get('key',[None,None])[1]
                if key is None:
                    continue
                k=int(key)
                if 0<=k<5:
                    masses[k]=float(terr.get('mass',0.0))
            total=masses.sum()
            if total>0:
                masses=masses/total
            mass_vecs.append(masses)

            metrics.append({
                't':t,'nnz':nnz,'gini_outdeg':gini,
                'outdeg_mean':float(out_deg.mean()),'outdeg_max':int(out_deg.max()),
                'alpha_kmin13':alpha13,'n_tail_kmin13':n_tail13,
                'W_mean':float(np.mean(W)),'W_std':float(np.std(W)),
                'adc_territories':len(adc.get('territories',[])),
            })

    dfm=pd.DataFrame(metrics).sort_values('t').reset_index(drop=True)
    dfm.to_csv(os.path.join(TABLES,'snapshot_metrics.csv'), index=False)

    mass=np.vstack(mass_vecs)
    mass_df=pd.DataFrame(mass, columns=[f'mass_key{k}' for k in range(5)])
    mass_df.insert(0,'t', dfm['t'].values)
    mass_df.to_csv(os.path.join(TABLES,'adc_mass_distribution.csv'), index=False)

    # Proof 1 recurrence matrix (Jaccard hubs)
    T=len(hub_bits)
    jac=np.zeros((T,T),dtype=np.float32)
    for i in range(T):
        bi=hub_bits[i]
        for j in range(i,T):
            bj=hub_bits[j]
            inter=(bi & bj).bit_count()
            union=(bi | bj).bit_count()
            val= inter/union if union else 0.0
            jac[i,j]=val
            jac[j,i]=val

    # heatmaps
    plt.figure(figsize=(6,5))
    plt.imshow(jac, aspect='auto', origin='lower')
    plt.colorbar(label='Jaccard(top20 hubs)')
    plt.title('Hub-occupancy recurrence (Jaccard)')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig1a_hub_jaccard_heatmap.png'), dpi=200)
    plt.close()

    theta=0.2
    plt.figure(figsize=(6,5))
    plt.imshow((jac>=theta).astype(int), aspect='auto', origin='lower')
    plt.colorbar(label=f'1 if Jaccard≥{theta}')
    plt.title(f'Recurrence plot (threshold {theta})')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig1b_hub_recurrence_binary_theta0p2.png'), dpi=200)
    plt.close()

    lags=np.arange(0,201)
    mean_jac=np.array([np.diag(jac,k=lag).mean() for lag in lags])
    plt.figure(figsize=(6,4))
    plt.plot(lags*60, mean_jac)
    plt.xlabel('Lag (ticks)')
    plt.ylabel('Mean Jaccard(top20 hubs)')
    plt.title('Hub recurrence vs lag')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig1c_hub_recurrence_vs_lag.png'), dpi=200)
    plt.close()

    rqa_rows=[]
    for th in [0.15,0.2,0.25,0.3]:
        R=(jac>=th).astype(np.uint8)
        m=rqa_metrics(R)
        m['theta']=th
        rqa_rows.append(m)
    pd.DataFrame(rqa_rows).to_csv(os.path.join(TABLES,'rqa_metrics_by_threshold.csv'), index=False)

    # Proof 3 free-energy landscape
    x=dfm['nnz'].values
    y=dfm['gini_outdeg'].values
    xbins=np.linspace(x.min(), x.max(), 60)
    ybins=np.linspace(y.min(), y.max(), 60)
    H, xedges, yedges=np.histogram2d(x,y,bins=[xbins,ybins],density=False)
    P=H/H.sum()
    P_s=gaussian_filter(P, sigma=1.0)

    # KDE for smoother F
    XY=np.column_stack([x,y])
    kde=gaussian_kde(XY.T, bw_method='scott')
    Xc=(xedges[:-1]+xedges[1:])/2
    Yc=(yedges[:-1]+yedges[1:])/2
    XX,YY=np.meshgrid(Xc,Yc,indexing='ij')
    pos=np.vstack([XX.ravel(),YY.ravel()])
    Pk=kde(pos).reshape(XX.shape)
    Pk=Pk/Pk.sum()
    Fk=-np.log(Pk+1e-12)

    kmeans=KMeans(n_clusters=2, random_state=0, n_init=10).fit(XY)
    centers=kmeans.cluster_centers_

    # save wells + barrier
    def Fk_at(xv,yv):
        ix=np.searchsorted(Xc, xv)-1
        iy=np.searchsorted(Yc, yv)-1
        ix=np.clip(ix,0,Fk.shape[0]-1); iy=np.clip(iy,0,Fk.shape[1]-1)
        return float(Fk[ix,iy])

    wells=[]
    for i,c in enumerate(centers):
        wells.append({'well_id':i,'nnz_center':c[0],'gini_center':c[1],'F_at_center':Fk_at(c[0],c[1])})
    pd.DataFrame(wells).to_csv(os.path.join(TABLES,'free_energy_wells.csv'), index=False)

    c1,c2=centers
    ts=np.linspace(0,1,300)
    Fs=np.array([Fk_at(c1[0]*(1-t)+c2[0]*t, c1[1]*(1-t)+c2[1]*t) for t in ts])
    barrier=float(Fs.max()-min(Fk_at(c1[0],c1[1]),Fk_at(c2[0],c2[1])))
    with open(os.path.join(TABLES,'free_energy_barrier_summary.json'),'w') as f:
        json.dump({
            'F_end_well0':Fk_at(c1[0],c1[1]),
            'F_end_well1':Fk_at(c2[0],c2[1]),
            'F_max_on_line':float(Fs.max()),
            'barrier_height':barrier
        }, f, indent=2)

    # Plot landscape
    plt.figure(figsize=(6,5))
    levels=np.linspace(np.percentile(Fk,5), np.percentile(Fk,95), 20)
    plt.contourf(XX,YY,Fk, levels=levels)
    plt.colorbar(label='F = -log P (KDE)')
    plt.scatter(x,y,s=5,alpha=0.4)
    plt.scatter(centers[:,0], centers[:,1], marker='x', s=100)
    plt.xlabel('Density proxy: nnz edges')
    plt.ylabel('Hierarchy proxy: Gini(out-degree)')
    plt.title('Empirical free-energy landscape')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig3_free_energy_landscape.png'), dpi=200)
    plt.close()

    plt.figure(figsize=(7,4))
    plt.plot(dfm['t'], dfm['nnz'])
    plt.xlabel('Tick')
    plt.ylabel('nnz edges')
    plt.title('nnz edges across snapshots')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig3b_nnz_timeseries.png'), dpi=200)
    plt.close()

    plt.figure(figsize=(7,4))
    plt.plot(dfm['t'], dfm['gini_outdeg'])
    plt.xlabel('Tick')
    plt.ylabel('Gini')
    plt.title('Gini(out-degree) across snapshots')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig3c_gini_timeseries.png'), dpi=200)
    plt.close()

    # Proof 4 statistical speed (Hellinger over ADC mass)
    speed=np.array([hellinger(mass[i], mass[i-1]) for i in range(1, mass.shape[0])])
    t_speed=dfm['t'].values[1:]
    pd.DataFrame({'t':t_speed,'hellinger_speed':speed}).to_csv(os.path.join(TABLES,'fisher_speed_hellinger.csv'), index=False)

    epochs=[]
    for (s,e) in [(0,6000),(6000,12000),(12000,18000),(18000,24000),(24000,30000)]:
        m=(t_speed>=s)&(t_speed<e)
        if m.sum()==0:
            continue
        epochs.append({'start':s,'end':e,'n':int(m.sum()),
                       'mean':float(speed[m].mean()),
                       'median':float(np.median(speed[m])),
                       'p90':float(np.quantile(speed[m],0.9))})
    pd.DataFrame(epochs).to_csv(os.path.join(TABLES,'fisher_speed_epoch_summary.csv'), index=False)

    plt.figure(figsize=(7,4))
    plt.plot(t_speed, speed, label='Hellinger(P_t,P_{t-1})')
    roll=pd.Series(speed).rolling(20, center=True, min_periods=5).median().values
    plt.plot(t_speed, roll, label='Rolling median (20)')
    mask=(t_speed<=18000)&np.isfinite(roll)&(roll>0)
    b,a=np.polyfit(t_speed[mask], np.log(roll[mask]), 1)
    tau=-1/b if b<0 else np.inf
    fit=np.exp(a + b*t_speed)
    plt.plot(t_speed, fit, linestyle='--', label=f'Exp fit τ≈{tau:.0f} ticks')
    plt.xlabel('Tick')
    plt.ylabel('Statistical speed')
    plt.title('Information-geometry proxy: statistical speed')
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig4_fisher_speed_timeseries.png'), dpi=200)
    plt.close()

    plt.figure(figsize=(6,4))
    plt.bar(range(len(epochs)), [e['mean'] for e in epochs])
    plt.xticks(range(len(epochs)), [f\"{e['start']}-{e['end']}\" for e in epochs], rotation=45, ha='right')
    plt.ylabel('Mean speed')
    plt.title('Mean speed by epoch')
    plt.tight_layout()
    plt.savefig(os.path.join(FIGS,'fig4b_fisher_speed_by_epoch.png'), dpi=200)
    plt.close()

    # Proof 2 PSD + avalanche on scalar slices
    begin=load_tick_series_from_zip(BEGIN_ZIP, member_hint="20260204_142311/events.jsonl")
    mid=load_tick_series_from_zip(MID_ZIP, member_hint="20260204_144053/events.jsonl")
    end=load_tick_series_from_zip(END_ZIP, member_hint="events.jsonl")

    segments=[('begin',begin),('mid',mid),('end',end)]
    rows=[]
    for name,df in segments:
        for var in ['firing_var','active_edges','active_synapses']:
            beta,slope,npts=psd_slope(df[var], fmin=1/500, fmax=0.2)
            rows.append({'segment':name,'var':var,'band':'0.002-0.2','beta':beta,'slope_loglog':slope,'n_freq_pts':npts,
                         't_min':int(df['t'].min()),'t_max':int(df['t'].max()),'n_ticks':len(df)})
    pd.DataFrame(rows).to_csv(os.path.join(TABLES,'psd_slopes.csv'), index=False)

    def plot_psd(var, fname):
        plt.figure(figsize=(6,4))
        for name,df in segments:
            freqs, psd = compute_psd(df[var].values)
            mask=(freqs>=1/500)&(freqs<=0.2)&(psd>0)
            plt.loglog(freqs[mask], psd[mask], label=f'{name}')
            slope, intercept=np.polyfit(np.log10(freqs[mask]), np.log10(psd[mask]), 1)
            beta=-slope
            f_line=np.array([freqs[mask].min(), freqs[mask].max()])
            p_line=10**(intercept + slope*np.log10(f_line))
            plt.loglog(f_line, p_line, linestyle='--', label=f'{name} fit β={beta:.2f}')
        plt.xlabel('Frequency (1/tick)')
        plt.ylabel('Power')
        plt.title(f'PSD of {var}')
        plt.legend(fontsize=7)
        plt.tight_layout()
        plt.savefig(os.path.join(FIGS,fname), dpi=200)
        plt.close()

    plot_psd('firing_var','fig2_psd_firing_var.png')
    plot_psd('active_edges','fig2_psd_active_edges.png')

    aval_rows=[]
    for name,df in segments:
        for var in ['firing_var','active_edges']:
            res=avalanche_scaling(df[var].values, q=0.75)
            res.update({'segment':name,'var':var,'q':0.75,'t_min':int(df['t'].min()),'t_max':int(df['t'].max())})
            aval_rows.append(res)
    pd.DataFrame(aval_rows).to_csv(os.path.join(TABLES,'avalanche_scaling.csv'), index=False)

    # CCDF plots for mid/firing_var
    aval, thr = compute_avalanches(mid['firing_var'].values, 0.75)
    dur=aval[:,0]; size=aval[:,1]

    def plot_ccdf(data, xlabel, title, fname):
        data=np.asarray(data)
        data=data[data>0]
        data=np.sort(data)
        n=len(data)
        ccdf=1.0 - np.arange(1,n+1)/n
        plt.figure(figsize=(5,4))
        plt.loglog(data, ccdf)
        plt.xlabel(xlabel)
        plt.ylabel('CCDF')
        plt.title(title)
        plt.tight_layout()
        plt.savefig(os.path.join(FIGS,fname), dpi=200)
        plt.close()

    plot_ccdf(size, 'Avalanche size (sum excess)', 'Avalanche size CCDF (mid, firing_var)', 'fig2b_avalanche_size_ccdf_mid.png')
    plot_ccdf(dur, 'Avalanche duration (ticks)', 'Avalanche duration CCDF (mid, firing_var)', 'fig2c_avalanche_duration_ccdf_mid.png')

    print("Done. Outputs written to:", OUTDIR)

if __name__ == "__main__":
    main()
