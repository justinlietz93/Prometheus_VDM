# VDM Blood Meridian run: scalar↔H5 structural alignment (v1)

This package validates **whether your scalar-only regime analysis has "structural teeth"** by using the saved `state_*.h5` checkpoints as offline geometry ground truth.

## Inputs used
- Run bundle extracted from `20260204_130222.zip`
  - `events.jsonl` (per-tick scalar telemetry)
  - `utd_events.jsonl` + rotated segments in `utd_events.zip` (macro events, including `say`)
  - `h5/state_*.h5` snapshots

## Quick run facts
- Tick span in `events.jsonl`: 139..4286 (n=4148)
- H5 snapshots analyzed: n=52 ticks 1140..4260 (cadence ~60 ticks)

## Input episodes (coarsened)
- has_input defined as `ute_text_count > 0`
- Episode detection parameters: gap_max=2, min_len=20 ticks
- Episodes found: 1

 episode_id  start_tick  end_tick  length
          1        1085      4286    3202

Interpretation:
- There is one long continuous input episode starting near tick 1085 and spanning the snapshot window.
  This is exactly what you want for *input-as-structured-perturbation* analyses.

## UTD "say" events found
- macro:say events: 2

  t text    score     b1_z  phase
614    . 0.605275 3.278736      0
757    . 0.612348 3.462314      0

Observation:
- All `say` events occur before the long input episode begins (no `say` inside the snapshot window).
  This limits B1/speech↔geometry alignment for *this* run, but the structure↔scalar alignment still works.

## Heavy-tail / inequality stability across snapshots
Out-degree Gini:
- mean = 0.541275
- std  = 0.003309
- CV   = 0.6114%

Power-law tail alpha (continuous MLE, fixed kmin=13):
- mean = 1.631323
- std  = 0.023005
- CV   = 1.4102%

Interpretation:
- Degree heavy-tail summaries are **stable invariants** across the snapshot window.

## Drift / representational turnover (consecutive snapshots)
Edge Jaccard (directed edge-set similarity):
- mean = 0.0476
- min  = 0.0364
- max  = 0.0608

Hub identity persistence:
- top20 out-degree overlap mean = 0.197
- top20 W overlap mean         = 0.023

W stability:
- nodewise corr mean = 0.036
- sorted corr mean   = 0.998

Interpretation:
- Distribution-level structure is stable (sorted-W correlations ~1),
  but node identities rotate (nodewise W correlations near 0). That matches your "biological representational drift" expectation.

## Structure↔scalar alignment (interval-level)
Correlation with `edge_jaccard` (higher jaccard = more structural similarity, lower = more churn):

{
  "mean_active_edges": -0.2280821441520589,
  "mean_connectome_entropy": -0.23167085247256886,
  "mean_vt_entropy": -0.20627381720409282,
  "mean_vt_coverage": -0.17454317843823297,
  "mean_adc_cycle_hits": -0.26583064014110996,
  "adc_spike_count_p99": -0.34617699299377036
}

Interpretation:
- Higher boundary-proxy activity (adc_cycle_hits spikes) tends to coincide with **lower edge_jaccard** (more connectome reconfiguration).

## Files
- `tables/tick_table_full_reduced.csv.gz`  (tick-level telemetry + merged say/episodes; **dict blobs removed**)
- `tables/snapshot_metrics.csv`
- `tables/snapshot_metrics_with_scalars.csv`
- `tables/drift_metrics_consecutive.csv`
- `tables/structure_scalar_alignment_intervals.csv`
- `figures/*.png`
- `SHA256SUMS.csv`

