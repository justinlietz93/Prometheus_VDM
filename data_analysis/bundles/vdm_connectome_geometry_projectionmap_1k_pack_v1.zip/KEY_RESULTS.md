# Connectome geometry + projection-map oriented analysis (1k)

## What this is
This pack derives a *coordinate system* from the connectome snapshots (spectral embedding + communities),
then builds a baseline 2D "projection grid" (32×32) by binning nodes in that coordinate system and summing the stationary random-walk density.

## Why it matters for transduction
If you later log walker positions/visits, you can update the same grid online by incrementing the cell(s) corresponding to visited nodes.
This gives you a high-dimensional, geometry-preserving readout (a "density landscape") instead of low-dimensional scalar vitals.

## Notable numbers
- Snapshots analyzed: 5
- Degree distributions across snapshots are similar (KS distances mostly ~0.01–0.05),
  while nodewise degree correlations are ~0 (suggesting rapid rewiring or index permutation between snapshots).
- Community counts (Louvain) are in the ~8–12 range depending on snapshot.

See `results/connectome_geometry_summary_across_snapshots.csv` and the plots folder.
