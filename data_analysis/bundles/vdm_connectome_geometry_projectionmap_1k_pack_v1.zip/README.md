# vdm_connectome_geometry_projectionmap_1k

## Inputs used
- state_394620.h5 ... state_394860.h5 from run folder:
  `Prometheus_VDM/runs/original_1kN_20250811_234347/`

## What it computes
1) Weighted CSR adjacency per snapshot (edge weight = per-row weight parameter W[i] replicated over outgoing edges).
2) Out-degree and stationary random-walk distribution (with tiny teleport for ergodicity).
3) Symmetrized graph spectral embedding (3D) + Louvain communities.
4) Per-node participation coefficient across communities.
5) A baseline 2D projection grid (32×32) produced by binning nodes by (emb1, emb2) and summing stationary density pi in each bin.

## How to reproduce
Run:
```bash
python scripts/run_connectome_geometry_projectionmap_analysis.py --run_dir <PATH_TO_RUN_DIR> --out_dir <OUT_DIR>
```

## Outputs
- results/*.csv : node tables, community sizes, top convergence nodes, baseline grids, cross-snapshot comparisons
- plots/*.png   : embeddings, degree CCDFs, baseline heatmaps
- provenance/*  : sha256 indexes
