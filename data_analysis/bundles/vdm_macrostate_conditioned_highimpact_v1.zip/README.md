# VDM Macrostate-Conditioned High-Impact Scalar Analysis (v1)

This package adds **macrostate-conditioned** (and macrostate×regime-conditioned) results on top of the earlier scalar-only analysis stack.

It does **not** attempt to reconstruct spatial “geometry” (walker paths / vt touches / flux fields), because the historical logs are pre-locality logging. Instead it answers: *what changes when you condition on the system’s own metastable macrostates?*

---

## Inputs included

- `inputs/tick_table_1k.csv.gz`  
  Unified per-tick table for the 1k run (PCA, macrostates, gate flags, scalar telemetry).

- `inputs/status_1k_with_say_and_regime.csv`  
  Provides `regime` labels and `change_score` for the overlapping tick range (not all ticks have regimes).

- `inputs/consciousness_proxy_window_metrics.csv`  
  Window-level coherence proxies (integration × differentiation × persistence × endogeneity × action gating).

- `inputs/goal_drive_atlas_windows_te.csv`  
  Window-level TE-based “goal drive” atlas.

---

## Outputs

### Core tables
- `tables/macrostate_profiles.csv`  
  Occupancy + mean vitals + gate rates per macrostate.

- `tables/macrostate_goal_drive_te.csv`  
  **Within-macrostate** TE directionality (reward↔exploration, entropy↔exploration), plus simple goal-drive indices.

- `tables/macrostate_regime_goal_drive_te.csv`  
  Same TE directionality, but conditioned on **macrostate × regime**.

- `tables/macro_change_rate_by_macrostate_input.csv`  
  Macrostate-change probability conditioned on input presence (a simple coupling diagnostic).

- `tables/macro_transition_probs_by_input.csv`  
  Transition probabilities `macro_t -> macro_{t+1}` split by `has_input`.

### Window-level coherence tables
- `tables/coherence_by_macrostate_windows.csv`  
  Distributional summary of window-level coherence metrics grouped by dominant macrostate.

- `tables/coherence_by_macrostate_regime_windows.csv`  
  Same, grouped by dominant macrostate and dominant regime.

- `tables/top_coherent_windows_by_macrostate.csv`  
  The top windows (by coherence score) per macrostate, annotated with regime mode/purity.

### Figures
- `figures/goal_drive_cov_dir_by_macrostate.png`  
- `figures/goal_drive_heatmap_macrostate_regime.png`  
- `figures/say_rate_heatmap_macrostate_regime.png`  
- `figures/coherence_score_boxplot_by_macrostate.png`

---

## Key findings (high-level)

1) **Goal-drive is macrostate-specific.**  
   The directed “reward→exploration” signature (TE directionality) concentrates in macrostates **0** and **2**.

2) **Input coupling is not uniform across macrostates.**  
   `has_input` shows measurable directed influence on exploration **primarily in macrostate 0** (TE-based proxy).

3) **Output gating is highly macrostate-selective.**  
   The system’s “did_say” gate fires disproportionately in **macrostate 1** (low input), consistent with an endogenous actuation mode rather than semantic decoding.

4) **Macrostate transitions depend strongly on whether external coupling is present.**  
   The transition matrix split by `has_input` shows a qualitative separation between input-coupled and decoupled macrostate dynamics.

---

## Reproduce

From the package root:

```bash
python scripts/run_macrostate_conditioned_analysis.py
```

Outputs will be written (overwritten) under `tables/`, `figures/`, and `SHA256SUMS.csv`.

---

## Notes

- Regime labels do not cover all ticks; any macrostate×regime results are computed on the subset where `regime` is known at both `t` and `t+1`.
- TE values involving rare events (e.g., `b1_spike`) are inherently noisy; prefer `reward↔coverage` and `entropy↔coverage` indices for drive comparisons.
