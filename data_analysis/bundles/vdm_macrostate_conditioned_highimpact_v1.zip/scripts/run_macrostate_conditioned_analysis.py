#!/usr/bin/env python3
"""
VDM macrostate-conditioned high-impact scalar analysis

Inputs (relative to this script's parent directory):
  inputs/tick_table_1k.csv.gz
  inputs/consciousness_proxy_window_metrics.csv
  inputs/goal_drive_atlas_windows_te.csv
  inputs/status_1k_with_say_and_regime.csv

Outputs:
  tables/*.csv
  figures/*.png
  SHA256SUMS.csv

This script is intentionally "boring": no fancy ML, no dense scans.
It computes macrostate-conditioned transfer entropy (TE) directionality indices,
macrostate×regime heatmaps, and window-level coherence summaries.
"""
from __future__ import annotations

import gzip
import io
import math
import os
import hashlib
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
INP = ROOT / "inputs"
OUT_T = ROOT / "tables"
OUT_F = ROOT / "figures"

OUT_T.mkdir(exist_ok=True, parents=True)
OUT_F.mkdir(exist_ok=True, parents=True)

def discretize_quantile(x: np.ndarray, n_bins: int = 8) -> np.ndarray:
    """Quantile discretization into bins [0..n_bins-1], -1 for NaN."""
    x = np.asarray(x)
    mask = np.isfinite(x)
    xs = x[mask]
    if xs.size == 0:
        return np.full_like(x, -1, dtype=int)
    uniq = np.unique(xs)
    nb = min(n_bins, uniq.size)
    if nb <= 1:
        out = np.zeros_like(x, dtype=int)
        out[~mask] = -1
        return out
    qs = np.linspace(0, 1, nb + 1)
    edges = np.unique(np.quantile(xs, qs))
    if edges.size <= 2:
        out = np.zeros_like(x, dtype=int)
        out[~mask] = -1
        return out
    out = np.full_like(x, -1, dtype=int)
    out[mask] = np.digitize(xs, edges[1:-1], right=False)
    return out

def transfer_entropy_discrete(x: np.ndarray, y_next: np.ndarray, y_prev: np.ndarray, base: float = 2.0) -> tuple[float, int]:
    """
    TE_{X->Y} = I(X_t; Y_{t+1} | Y_t) for discrete arrays.
    Arrays must be same length and contain ints, with -1 representing missing.
    """
    x = np.asarray(x)
    y_next = np.asarray(y_next)
    y_prev = np.asarray(y_prev)
    assert x.shape == y_next.shape == y_prev.shape

    mask = (x >= 0) & (y_next >= 0) & (y_prev >= 0)
    x = x[mask]
    y_next = y_next[mask]
    y_prev = y_prev[mask]
    N = x.size
    if N == 0:
        return float("nan"), 0

    c_yx = Counter(zip(y_prev, x))
    c_yy = Counter(zip(y_next, y_prev))
    c_y = Counter(y_prev)
    c_yyx = Counter(zip(y_next, y_prev, x))

    te = 0.0
    log = math.log
    for (y1, y0, xv), c in c_yyx.items():
        p_xyz = c / N
        p_y_given_yx = c / c_yx[(y0, xv)]
        p_y_given_y = c_yy[(y1, y0)] / c_y[y0]
        ratio = p_y_given_yx / p_y_given_y
        if ratio <= 0:
            continue
        te += p_xyz * (log(ratio) / log(base))
    return te, N

def te_x_to_y_for_idx(idx: np.ndarray, x_disc: np.ndarray, y_disc: np.ndarray) -> tuple[float, int]:
    if idx.size == 0:
        return float("nan"), 0
    x = x_disc[idx]
    y_prev = y_disc[idx]
    y_next = y_disc[idx + 1]
    return transfer_entropy_discrete(x, y_next, y_prev)

def window_mode_and_purity(arr: np.ndarray, start: int, end: int) -> tuple[float, float, int]:
    sub = arr[start:end + 1]
    if sub.dtype.kind == "f":
        finite = np.isfinite(sub)
        if finite.sum() == 0:
            return float("nan"), 0.0, 0
        vals = sub[finite].astype(int)
        counts = Counter(vals)
        mode_val = max(counts.items(), key=lambda kv: kv[1])[0]
        purity = counts[mode_val] / len(vals)
        return mode_val, purity, len(vals)
    vals = sub.astype(int)
    counts = Counter(vals)
    mode_val = max(counts.items(), key=lambda kv: kv[1])[0]
    purity = counts[mode_val] / len(vals)
    return mode_val, purity, len(vals)

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    # Load tick table
    tick_gz = (INP / "tick_table_1k.csv.gz").read_bytes()
    tick = pd.read_csv(io.BytesIO(gzip.decompress(tick_gz)))
    tick = tick.sort_values("t").reset_index(drop=True)

    # Load regime labels and de-dup by t
    status = pd.read_csv(INP / "status_1k_with_say_and_regime.csv")
    s1k = status[status["neurons"] == 1000].copy()
    s1k_unique = s1k.sort_values("t").groupby("t", as_index=False).agg(
        regime=("regime", lambda x: x.value_counts().idxmax()),
        change_score=("change_score", "mean"),
        score=("score", "mean"),
    )
    merged = tick.merge(s1k_unique, on="t", how="left")

    # Global discretizations for TE
    disc = {}
    for col in ["sie_v2_reward_mean", "connectome_entropy", "vt_coverage"]:
        disc[col] = discretize_quantile(merged[col].values, n_bins=8)
    disc["b1_spike"] = merged["b1_spike"].astype(int).values
    disc["reconfig_spike"] = merged["reconfig_spike"].astype(int).values
    disc["has_input"] = merged["has_input"].astype(int).values

    macro = merged["macrostate"].astype(int).values
    macro_next = np.roll(macro, -1)
    regime = merged["regime"].values
    regime_next = np.roll(regime, -1)

    macro_vals = sorted(merged["macrostate"].unique())

    def within_macro_pairs(m: int) -> np.ndarray:
        return np.where((macro[:-1] == m) & (macro_next[:-1] == m))[0]

    def within_macro_regime_pairs(m: int, r: int) -> np.ndarray:
        return np.where(
            (macro[:-1] == m) & (macro_next[:-1] == m) &
            np.isfinite(regime[:-1]) & np.isfinite(regime_next[:-1]) &
            (regime[:-1] == r) & (regime_next[:-1] == r)
        )[0]

    # Macrostate-conditioned TE
    rows = []
    for m in macro_vals:
        idx = within_macro_pairs(m)
        te_r2c, n = te_x_to_y_for_idx(idx, disc["sie_v2_reward_mean"], disc["vt_coverage"])
        te_c2r, _ = te_x_to_y_for_idx(idx, disc["vt_coverage"], disc["sie_v2_reward_mean"])
        te_e2c, _ = te_x_to_y_for_idx(idx, disc["connectome_entropy"], disc["vt_coverage"])
        te_c2e, _ = te_x_to_y_for_idx(idx, disc["vt_coverage"], disc["connectome_entropy"])
        te_r2b1, _ = te_x_to_y_for_idx(idx, disc["sie_v2_reward_mean"], disc["b1_spike"])
        te_e2b1, _ = te_x_to_y_for_idx(idx, disc["connectome_entropy"], disc["b1_spike"])
        te_r2rc, _ = te_x_to_y_for_idx(idx, disc["sie_v2_reward_mean"], disc["reconfig_spike"])
        te_e2rc, _ = te_x_to_y_for_idx(idx, disc["connectome_entropy"], disc["reconfig_spike"])
        te_in2c, _ = te_x_to_y_for_idx(idx, disc["has_input"], disc["vt_coverage"])
        te_in2rc, _ = te_x_to_y_for_idx(idx, disc["has_input"], disc["reconfig_spike"])

        rows.append({
            "macrostate": m,
            "n_pairs": int(idx.size),
            "te_reward_to_cov": te_r2c,
            "te_cov_to_reward": te_c2r,
            "te_entropy_to_cov": te_e2c,
            "te_cov_to_entropy": te_c2e,
            "dir_reward_cov": te_r2c - te_c2r,
            "dir_entropy_cov": te_e2c - te_c2e,
            "goal_drive_cov_simple": te_r2c - te_e2c,
            "goal_drive_cov_dir": (te_r2c - te_c2r) - (te_e2c - te_c2e),
            "te_reward_to_b1": te_r2b1,
            "te_entropy_to_b1": te_e2b1,
            "goal_drive_b1": te_r2b1 - te_e2b1,
            "te_reward_to_reconfig_spike": te_r2rc,
            "te_entropy_to_reconfig_spike": te_e2rc,
            "goal_drive_reconfig": te_r2rc - te_e2rc,
            "te_has_input_to_cov": te_in2c,
            "te_has_input_to_reconfig_spike": te_in2rc,
        })
    macro_te = pd.DataFrame(rows)
    macro_te.to_csv(OUT_T / "macrostate_goal_drive_te.csv", index=False)

    # Macrostate profiles
    prof = merged.groupby("macrostate").agg(
        n_ticks=("t", "count"),
        vt_coverage_mean=("vt_coverage", "mean"),
        vt_entropy_mean=("vt_entropy", "mean"),
        connectome_entropy_mean=("connectome_entropy", "mean"),
        active_edges_mean=("active_edges", "mean"),
        reward_mean=("sie_v2_reward_mean", "mean"),
        valence_mean=("sie_v2_valence_01", "mean"),
        say_rate=("did_say", "mean"),
        input_rate=("has_input", "mean"),
        ute_text_mean=("ute_text_count", "mean"),
        b1_spike_rate=("b1_spike", "mean"),
        reconfig_spike_rate=("reconfig_spike", "mean"),
        cohesion_components_mean=("cohesion_components", "mean"),
    ).reset_index()
    prof.to_csv(OUT_T / "macrostate_profiles.csv", index=False)

    # Macrostate×regime TE
    reg_vals = sorted([int(x) for x in pd.Series(regime[np.isfinite(regime)]).unique()])
    rows = []
    for m in macro_vals:
        for r in reg_vals:
            idx = within_macro_regime_pairs(m, r)
            if idx.size == 0:
                continue
            te_r2c, _ = te_x_to_y_for_idx(idx, disc["sie_v2_reward_mean"], disc["vt_coverage"])
            te_c2r, _ = te_x_to_y_for_idx(idx, disc["vt_coverage"], disc["sie_v2_reward_mean"])
            te_e2c, _ = te_x_to_y_for_idx(idx, disc["connectome_entropy"], disc["vt_coverage"])
            te_c2e, _ = te_x_to_y_for_idx(idx, disc["vt_coverage"], disc["connectome_entropy"])
            te_r2rc, _ = te_x_to_y_for_idx(idx, disc["sie_v2_reward_mean"], disc["reconfig_spike"])
            te_e2rc, _ = te_x_to_y_for_idx(idx, disc["connectome_entropy"], disc["reconfig_spike"])
            te_in2c, _ = te_x_to_y_for_idx(idx, disc["has_input"], disc["vt_coverage"])
            te_in2rc, _ = te_x_to_y_for_idx(idx, disc["has_input"], disc["reconfig_spike"])

            rows.append({
                "macrostate": m,
                "regime": r,
                "n_pairs": int(idx.size),
                "te_reward_to_cov": te_r2c,
                "te_entropy_to_cov": te_e2c,
                "te_cov_to_reward": te_c2r,
                "te_cov_to_entropy": te_c2e,
                "goal_drive_cov_dir": (te_r2c - te_c2r) - (te_e2c - te_c2e),
                "te_reward_to_reconfig_spike": te_r2rc,
                "te_entropy_to_reconfig_spike": te_e2rc,
                "goal_drive_reconfig": te_r2rc - te_e2rc,
                "te_has_input_to_cov": te_in2c,
                "te_has_input_to_reconfig_spike": te_in2rc,
            })
    combo_te = pd.DataFrame(rows)
    combo_te.to_csv(OUT_T / "macrostate_regime_goal_drive_te.csv", index=False)

    # Load window metrics and annotate with regime mode/purity
    windows = pd.read_csv(INP / "consciousness_proxy_window_metrics.csv")
    t0 = int(tick["t"].iloc[0])
    # Build aligned arrays (assumes contiguous t)
    macro_arr = tick["macrostate"].astype(int).values
    regime_arr = merged["regime"].values

    reg_mode_list = []
    reg_purity_list = []
    n_reg_list = []
    mac_purity_list = []
    for _, row in windows.iterrows():
        s = int(row["idx_start"])
        e = int(row["idx_end"])
        reg_mode, reg_purity, n_reg = window_mode_and_purity(regime_arr, s, e)
        mac_mode, mac_purity, _ = window_mode_and_purity(macro_arr, s, e)
        reg_mode_list.append(reg_mode)
        reg_purity_list.append(reg_purity)
        n_reg_list.append(n_reg)
        mac_purity_list.append(mac_purity)

    windows["regime_mode"] = reg_mode_list
    windows["regime_purity"] = reg_purity_list
    windows["n_regime_ticks"] = n_reg_list
    windows["macro_purity"] = mac_purity_list
    windows.to_csv(OUT_T / "consciousness_proxy_window_metrics_with_regime.csv", index=False)

    # Goal-drive atlas windows annotation
    gd = pd.read_csv(INP / "goal_drive_atlas_windows_te.csv")
    reg_mode_list = []
    reg_purity_list = []
    n_reg_list = []
    mac_purity_list = []
    for _, row in gd.iterrows():
        s = int(row["idx_start"])
        e = int(row["idx_end"])
        reg_mode, reg_purity, n_reg = window_mode_and_purity(regime_arr, s, e)
        mac_mode, mac_purity, _ = window_mode_and_purity(macro_arr, s, e)
        reg_mode_list.append(reg_mode)
        reg_purity_list.append(reg_purity)
        n_reg_list.append(n_reg)
        mac_purity_list.append(mac_purity)
    gd["regime_mode"] = reg_mode_list
    gd["regime_purity"] = reg_purity_list
    gd["n_regime_ticks"] = n_reg_list
    gd["macro_purity"] = mac_purity_list
    gd.to_csv(OUT_T / "goal_drive_atlas_windows_with_regime.csv", index=False)

    # Macrostate transitions conditioned on input presence
    has_in = tick["has_input"].astype(int).values
    macro_next2 = np.roll(macro_arr, -1)
    macro_change = (macro_next2[:-1] != macro_arr[:-1]).astype(int)
    df_trans = pd.DataFrame({"macrostate": macro_arr[:-1], "has_input": has_in[:-1], "macro_change": macro_change})
    trans_stats = df_trans.groupby(["macrostate", "has_input"]).agg(n=("macro_change", "size"), p_change=("macro_change", "mean")).reset_index()
    trans_stats.to_csv(OUT_T / "macro_change_rate_by_macrostate_input.csv", index=False)

    df_pairs = pd.DataFrame({"macro_t": macro_arr[:-1], "macro_next": macro_next2[:-1], "has_input": has_in[:-1]})
    trans_counts = df_pairs[df_pairs["macro_t"] != df_pairs["macro_next"]].groupby(["macro_t", "macro_next", "has_input"]).size().reset_index(name="count")
    trans_counts.to_csv(OUT_T / "macro_transition_counts_by_input.csv", index=False)

    counts = df_pairs.groupby(["macro_t", "has_input", "macro_next"]).size().reset_index(name="count")
    counts["total"] = counts.groupby(["macro_t", "has_input"])["count"].transform("sum")
    counts["p"] = counts["count"] / counts["total"]
    counts.to_csv(OUT_T / "macro_transition_probs_by_input.csv", index=False)

    # Figures
    plt.figure(figsize=(7, 4))
    plt.bar(macro_te["macrostate"].astype(int).values, macro_te["goal_drive_cov_dir"].values)
    plt.xlabel("Macrostate")
    plt.ylabel("Goal-drive index (dir-corrected TE)")
    plt.title("Goal-drive (reward vs entropy) by macrostate")
    plt.tight_layout()
    plt.savefig(OUT_F / "goal_drive_cov_dir_by_macrostate.png", dpi=200)
    plt.close()

    heat = combo_te.pivot(index="macrostate", columns="regime", values="goal_drive_cov_dir")
    plt.figure(figsize=(7, 3.5))
    plt.imshow(heat.values, aspect="auto")
    plt.colorbar(label="Goal-drive (dir-corrected TE)")
    plt.yticks(range(heat.shape[0]), heat.index)
    plt.xticks(range(heat.shape[1]), heat.columns)
    plt.xlabel("Regime")
    plt.ylabel("Macrostate")
    plt.title("Goal-drive heatmap (macrostate × regime)")
    plt.tight_layout()
    plt.savefig(OUT_F / "goal_drive_heatmap_macrostate_regime.png", dpi=200)
    plt.close()

    # Say rate heatmap from regime-labeled subset
    reg_df = merged[np.isfinite(merged["regime"])].copy()
    reg_df["regime"] = reg_df["regime"].astype(int)
    say_heat = reg_df.groupby(["macrostate", "regime"])["did_say"].mean().unstack()
    plt.figure(figsize=(7, 3.5))
    plt.imshow(say_heat.values, aspect="auto")
    plt.colorbar(label="Say rate (did_say per tick)")
    plt.yticks(range(say_heat.shape[0]), say_heat.index)
    plt.xticks(range(say_heat.shape[1]), say_heat.columns)
    plt.xlabel("Regime")
    plt.ylabel("Macrostate")
    plt.title("Output gating rate heatmap (macrostate × regime)")
    plt.tight_layout()
    plt.savefig(OUT_F / "say_rate_heatmap_macrostate_regime.png", dpi=200)
    plt.close()

    # Hash index
    hash_rows = []
    for root, _, files in os.walk(ROOT):
        for fn in files:
            if fn.startswith("."):
                continue
            path = Path(root) / fn
            rel = str(path.relative_to(ROOT))
            # include only outputs and script itself and inputs
            if rel.startswith(("tables/", "figures/", "scripts/", "inputs/")) or rel in ("README.md",):
                hash_rows.append({"sha256": sha256_file(path), "bytes": path.stat().st_size, "path": rel})
    pd.DataFrame(hash_rows).sort_values("path").to_csv(ROOT / "SHA256SUMS.csv", index=False)

if __name__ == "__main__":
    main()
