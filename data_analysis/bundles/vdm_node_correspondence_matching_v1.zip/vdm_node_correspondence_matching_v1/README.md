# VDM snapshot node correspondence (offline)

This package answers one specific question:

> How much of the apparent snapshot-to-snapshot "edge churn" could be explained by **node re-indexing / permutation** rather than true structural change?

You already expect representational drift (biological-style dynamic coding). This analysis does **not** assume neuron identity is fixed.
Instead, it tries to find an **approximate best correspondence** between node indices across checkpoints, using only sparse graph structure.

## Inputs

These were used:

- `state_394620.h5`
- `state_394680.h5`
- `state_394740.h5`
- `state_394800.h5`
- `state_394860.h5`

Each checkpoint contains:
- `sparse/row_ptr`, `sparse/col_idx` (CSR adjacency, binary directed)
- `sparse/W` (node field)
- `adc_json` (not used here)

## Method summary (sparse, no dense scans)

For each snapshot we compute a **node feature vector** consisting of:

- out-degree, in-degree, W
- 1-hop neighbor sums: sum(out_deg of out-neighbors), sum(in_deg of out-neighbors), sum(W of out-neighbors)
- 2-hop features via sparse CSR multiply: row-sum(A^2), and A^2 dot out_deg, A^2 dot W
- spectral coordinates from an undirected normalized Laplacian embedding (k=8) computed via `scipy.sparse.linalg.eigsh`

For each pair of snapshots (A,B), we solve a **minimum-cost bipartite assignment** (Hungarian algorithm) on the
pairwise Euclidean distance between z-scored node features, producing a permutation mapping A-index → B-index.

Then we evaluate:
- **Directed edge Jaccard** between A edge set and the permuted B edge set
- nodewise correlations of W and degrees after alignment
- hub persistence (top-20 overlap) after alignment
- mapping transitivity (A→B→C vs A→C), which measures how uniquely-determined the matching is

## Key results (the headline numbers)

### Edge overlap improves, but remains low

Consecutive snapshot pairs (dt=60 ticks):

- raw edge Jaccard: ~0.011–0.013 (≈ random)
- deg+W rank alignment: ~0.038–0.039
- **graph-signature matching (this work): ~0.057–0.061**

Even under the best sparse feature-based matching here,
only ~11% of directed edges persist between consecutive snapshots.

This strongly suggests that:
- some apparent drift is indexing/permutation,
- but **most** drift is true edge turnover / rewiring in this time window.

### W and degree identity coherence increases under matching

Example (394620→394680):
- raw corr(W_t, W_{t+dt}) ≈ 0.007
- **graph-signature corr(W_t, W_{t+dt} aligned) ≈ 0.81**

So there *is* real node-level continuity that can be recovered (partial "role persistence").

### Hub persistence (top-20) becomes nontrivial under matching

After graph-signature alignment:
- top-20 out-degree hub overlap ≈ 0.30–0.45 (random mean ≈ 0.02)
- top-20 W hub overlap ≈ 0.30–0.45 (random mean ≈ 0.02)

This supports a “role family” view:
- heavy-tail inequality is stable
- but exact hub identities are partially rotating / exchanging.

### Matching is not transitive (many nodes are interchangeable)

Triples show composition consistency only ~8–10%:
(A→B→C) often differs from direct (A→C).

That’s a signature of **non-unique matchings** (many nodes share similar local signatures),
consistent with dynamic coding / representational drift.

## Files

- `tables/pair_matching_metrics_consecutive.csv`
- `tables/pair_matching_metrics_allpairs_raw_vs_graphsig.csv`
- `tables/hub_overlap_top20_metrics.csv`
- `tables/matching_transitivity_triples.csv`
- `tables/mapping_graphsig_*_to_*.csv.gz` (1000-row node maps)
- `figures/*.png` (overlap bars, cost histograms, hub overlap, transitivity)

## Repro

Run:

```bash
python scripts/run_node_correspondence_matching.py --h5_dir /path/to/checkpoints --out_dir out/
```

It will regenerate `tables/` and `figures/`.

## Interpretation note (important)

Biological plausibility: representational drift is normal. This analysis does **not** call it a bug.

The point is narrower: earlier “edge turnover” estimates were computed in raw index space, which could
overstate churn if the runtime reindexes nodes between checkpoints.

Even after allowing a strong reindexing correction via sparse matching,
edge persistence remains ~10–12% over 60 ticks in this slice — i.e., churn is still very large.

So, if you later want “structural reset” evidence aligned to B1/reconfig transitions,
you’ll want **more checkpoint coverage across boundary events** (the current 5 checkpoints do not include B1 spikes).
