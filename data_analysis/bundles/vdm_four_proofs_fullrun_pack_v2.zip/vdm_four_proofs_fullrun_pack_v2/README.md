# VDM Four Proofs Offline Analysis Pack (Full Run)

This pack reproduces four offline analyses (no runtime code changes required) intended to support a paper-style claim that **VDM exhibits complex adaptive system signatures** on top of **structural plasticity** (changing topology over time).

## Raw inputs used (as provided in this environment)

**Scalar tick telemetry (events.jsonl slices):**
- `/mnt/data/20260204_142311.zip`  (ticks ~0–8247)
- `/mnt/data/20260204_144053.zip`  (ticks ~8264–16504)
- `/mnt/data/20260204_145853.zip`  (ticks ~16588–24825)
- `/mnt/data/events.jsonl.zip`     (ticks ~24910–29176)

Note: there are small uncovered gaps: `8248–8263`, `16505–16587`, `24826–24909` (184 ticks total).

**Connectome checkpoint snapshots (H5):**
- `/mnt/data/snapshots_backup.zip` extracted to `/mnt/data/_snapshots_backup/snapshots_backup/state_*.h5`
- Snapshot ticks: `60..29160` step `60` (N=485 snapshots).

**UTD macro events:**
- `/mnt/data/utd_events.zip` (available here) contains macro status + ~30 macro `say` events covering ticks ~157–4304.
  These are merged into the tick table as `did_say` for that tick span only.

## Outputs

- `tables/tick_table_full.csv.gz` — unified per-tick scalar table (reindexed to full tick range).
- `tables/snapshot_metrics.csv` — per-snapshot sparse connectome metrics (nnz, Gini, alpha, hubs, territory masses).
- `figures/*.png` — proof figures + supporting plots.
- `scripts/*.py` — reproducibility scripts.
- `SHA256SUMS.csv` — hashes for everything in this pack.

## Key Findings (what the figures show)

### Proof 1 — Dynamic Core / “Sub-personalities” via hub recurrence (TRQA-style)
**Figure:** `figures/proof1_hub_recurrence_jaccard.png`

- We compute the **Top-20 hub set** per snapshot (out-degree hubs), then compute a **Jaccard similarity matrix** across time.
- Result: strong **block-diagonal structure** (metastable hub coalitions) plus **off-diagonal recurrence** (return to earlier coalitions).
- Mean off-diagonal Jaccard is low (~0.08), but the **max off-diagonal** similarity is very high (≥0.9), and there are multiple **far** recurrences (e.g. ≥0.6 similarity across thousands of ticks).

Supporting:
- `figures/proof1_recurrence_binary_theta0p3.png`
- `tables/proof1_rqa_metrics_by_threshold.csv`
- `tables/proof1_far_recurrence_pairs_jaccard_ge_0p6.csv`

Interpretation (paper-safe): the “dynamic core” is **not a fixed set of nodes**; instead, a rotating coalition of hub nodes dominates over multi-minute windows, with partial returns to earlier coalitions.

### Proof 2 — Criticality-adjacent dynamics (PSD + avalanche scaling)
**Figures:** `figures/proof2_psd_firing_var_steady.png`, `figures/proof2_avalanche_*`

- PSD on the **steady-state** portion of the run (ticks ≥500) shows:
  - `firing_var` exhibits a **near 1/f** region over ~0.1–1.0 Hz (β≈1).
  - `active_edges` / `active_synapses` are closer to **1/f²** over the same band (Brownian-like).
- Avalanche-style thresholding (q0.75) produces heavy-tailed size/duration CCDFs (not a formal proof of SOC, but consistent with scale-free bursts).

Tables:
- `tables/proof2_psd_beta_summary.csv`
- `tables/proof2_avalanche_summary.csv`

Interpretation: some internal channels show **pink-noise-like** behavior on mid frequencies, with burst distributions that are **power-law-like**.

### Proof 3 — Thermodynamic phase switching (empirical free-energy landscape)
**Figures:** `figures/proof3_free_energy_landscape.png`, `figures/proof3_free_energy_landscape_kde.png`

Order parameters:
- x = **edge density** (mean out-degree)
- y = **hierarchy** (Gini of out-degree)

Result:
- The snapshot cloud separates into **two basins**:
  - Basin A: **low edge density + high Gini** (sparser, more hierarchical)
  - Basin B: **high edge density + low Gini** (denser, less hierarchical)
- A 2-component GMM finds two stable clusters with **only ~8 transitions** across the full run.
- These basins align strongly with input coupling:
  - Basin A has `has_input≈0.99`
  - Basin B has `has_input≈0.18`

Tables:
- `tables/proof3_bistability_cluster_summary.csv`
- `tables/proof3_bistability_dwell_runs.csv`

Interpretation: the system shows a **bistable operating landscape** in (density, hierarchy) space, with a barrier (rare switching) and strong coupling of the “reading-like” basin to external input presence.

### Proof 4 — Information geometry / “learning speed” via mass-distribution drift
**Figure:** `figures/proof4_fisher_speed_hellinger.png`

- Using ADC territory mass distributions per snapshot (5 territories), we compute **Hellinger distance** between consecutive snapshots.
- Result: “speed” decays from high early values to a low late plateau, consistent with a **search → stabilization** dynamic.

Table:
- `tables/proof4_fisher_speed_hellinger.csv`

Interpretation: distributional drift of the structural “mass” becomes slower over time, consistent with **symmetry breaking / backbone consolidation**.

## Reproducibility

Run scripts in order:

```bash
python scripts/00_build_tick_table.py \
  --events /mnt/data/20260204_142311.zip /mnt/data/20260204_144053.zip /mnt/data/20260204_145853.zip /mnt/data/events.jsonl.zip \
  --utd_zip /mnt/data/utd_events.zip \
  --out_csv_gz tables/tick_table_full.csv.gz

python scripts/01_compute_snapshot_metrics.py \
  --snap_dir /mnt/data/_snapshots_backup/snapshots_backup \
  --out_csv tables/snapshot_metrics.csv

python scripts/02_four_proofs.py \
  --tick_table tables/tick_table_full.csv.gz \
  --snapshot_metrics tables/snapshot_metrics.csv \
  --out_dir .
```

## Caution / scope notes

- These are **signatures consistent with** complex adaptive systems and neuro-like regimes; they are **not** proofs of “consciousness.”
- PSD slopes and avalanche fits depend on frequency range / threshold choice; the scripts expose these parameters.