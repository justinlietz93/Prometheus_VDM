VDM Refresh Horizon Bundle
==========================

Contains refresh-horizon plots and the CSV table used to generate them.

Files:
- refresh_horizon_default_sentinel.png
- refresh_horizon_vs_N.png
- refresh_horizon_suite_vs_N.png
- refresh_horizon_vs_N.csv
