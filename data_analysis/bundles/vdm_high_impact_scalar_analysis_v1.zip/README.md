# VDM high-impact scalar telemetry analysis (v1)

This package contains **high-impact analyses that are possible with the pre-locality (scalar-telemetry) logs**. It **does not attempt geometry reconstruction** (underconstrained without per-site/per-path streams).

## Data source

- `1000_neurons_events.zip` → `utd_events.jsonl`
  - Per-tick `status` payloads (scalar telemetry)
  - Input `text` payloads (messages) immediately preceding each status tick (used to build per-tick input features)
  - Macro `say` events with `why.t` and text (used as actuation/gating labels)

## 1) Decoder readout = motor gate (not semantics)

**1k run overview**
- ticks: **68403**
- say ticks: **312**
- overall say rate: **0.004561**
- input-present rate (`ute_text_count>0`): **0.521**

We fit a **minimal logistic motor-gate model** (time-split, class-balanced) to predict `did_say` using:

`[b1_z, vt_coverage, active_edges, connectome_entropy, has_input, recent_input_any_W50, phase]`

Results:
- Test AUC: **0.9994**
- Average precision: **0.8600**
- Coefficients + univariate AUCs: see `tables/decoder_readout_spec.csv`
- Plots: `figures/motor_gate_logit_coefficients.png`, `figures/motor_gate_pr_curve.png`

Interpretation:
- Output is best treated as a **physical actuation aperture**:
  - **opens** on **B1 pulses** (`b1_z`),
  - favors **higher vt_coverage**,
  - **suppressed** by higher **active_edges** (synaptic load),
  - **suppressed** by higher **connectome_entropy** *after controlling for other state variables*,
  - modulated by **external coupling** (`has_input` now vs `recent_input_any_W50`).

## 2) Goal drive vs entropy drive (directionality atlas)

We compute **windowed transfer entropy (TE)**:
- reward → exploration (`sie_v2_reward_mean` → `vt_coverage`)
- entropy → exploration (`connectome_entropy` → `vt_coverage`)

Deliverables:
- `tables/goal_drive_atlas_ranked.csv` (ranked windows, with drive label + actuation stats)
- Plots: `figures/goal_drive_index_over_time.png`, `figures/goal_drive_vs_say_rate_scatter.png`

Global TE (1k, 8-bin discretization):
- TE(reward_mean → coverage): **0.1335 bits**
- TE(entropy → coverage): **0.1294 bits**
- TE(reward_mean → B1): **0.0591 bits**
- TE(entropy → B1): **0.1921 bits**

Empirically, reward/valence tends to **drive exploration/coverage**, while entropy tends to **drive reconfiguration (B1)**.

## 3) Metastable macrostates & transitions

We build a Markov model over **microstates** (K=60 k-means clusters in PCA space of internal telemetry),
then coarse-grain to **k=4 macrostates** (dominant spectral gap).

Deliverables:
- `tables/macrostate_segments_k4.csv`
- `tables/macrostate_transitions_k4.csv`
- `tables/macrostate_dwell_times_k4.csv`
- `tables/macrostate_dwell_powerlaw_fit.csv`
- `tables/event_triggered_means_around_macro_transitions.csv`
- Plots: `figures/microstate_eigenspectrum.png`, `figures/microstate_implied_timescales.png`, `figures/macrostate_timeline_k4.png`,
  `figures/macrostate_dwell_ccdf_powerlaw.png`, `figures/eta_*_around_transitions.png`

Key findings (1k):
- macro transitions: **342**
- Dwell times are heavy-tailed (example fit):
  - xmin=200, alpha≈1.95 (n_tail=68)
- **Transition boundary enrichment** (vs baseline):
  - B1 spikes: ~**43.3×**
  - reconfig spikes: ~**11.1×**
  - actuation (`did_say`): ~**7.1×**

## 4) Input → internal coupling; internal → output gating

We build per-tick input features from TF-IDF → SVD topics and test:

- **Input → internal**: incremental ΔR² for predicting internal PCs at various horizons:
  - `tables/coupling_input_to_internal_deltaR2.csv`
  - plot: `figures/coupling_deltaR2_over_horizon.png`
- **Internal → output gate**: adding text topics to the actuation model yields ~0 improvement:
  - `tables/coupling_internal_to_output_gate.csv`

A representative internal-dynamics result:
- `tables/coupling_delta_PC2_summary.csv`:
  - ΔR² for predicting **ΔPC2** (t+1−t) increases by **0.0089** when adding input text topics.

## 5) Consciousness-adjacent episode ranking

We compute per-window proxies:
- **Integration**: Gaussian total correlation on correlation matrix
- **Differentiation**: participation ratio
- **Persistence**: PC1 lag-20 autocorrelation
- **Endogeneity**: negative ΔR² of adding input to an internal predictor
- **Backbone stability**: correlation-network turnover
- plus actuation/input rates

Deliverables:
- `tables/consciousness_proxy_window_metrics.csv`
- `tables/candidate_coherent_episodes_top20.csv`
- Plots: `figures/coherence_score_over_time.png`, `figures/coherence_score_top_windows_highlight.png`

## 6) Scaling risk dashboard (what we *can* compare here)

This dataset contains short segments at **N=2000** and **N=3000** in the same `utd_events.jsonl`.
We compute a compact dashboard (rates, TE, integration/differentiation, etc.):

- `tables/scaling_risk_dashboard.csv`
- `figures/scaling_*.png`

Caution: the 2k/3k segments are much shorter than the 1k run, so treat them as *indicative only*.

## Reproducibility

- `scripts/run_all.py` reproduces the analysis and writes outputs into `out_dir`.
- `scripts/requirements.txt` lists minimal dependencies.
- `SHA256SUMS.csv` contains hashes of all artifacts in this package.

