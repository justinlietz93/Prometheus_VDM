# VDM Intent vs Composer Audit (2026-02-04 UTD run)

This pack answers a narrow question:

> **Is the surface `macro:say` text a clean readout of internal intent, or mostly the Markov/n-gram composer?**

## What this analysis uses
- `utd_events.jsonl.20260204_150151.zip` (parsed into:
  - per-tick `status` telemetry (scalars)
  - input text lines (assigned to the next status tick)
  - `macro:say` events (`args.text` + `why` metrics)

No runtime modifications. No dense scans.

## Key outputs
- `tables/say_event_composer_audit_metrics.csv`
  - Per say-event metrics:
    - **Composer signature:** `tri_frac_in_corpus`
    - **Copy vs recombination:** `lcs_substr_len` vs the best-matching input tick
    - **Reactive overlap:** `imm_jaccard` (say vs same-tick input token set)
    - **Memory-pointer proxy:** past-TFIDF top match (`past_top1_tick`, `past_top1_sim`, `past_sim_gap`)
    - Internal state at say tick: `b1_z`, `active_edges`, `connectome_entropy`, `vt_coverage`, `valence`

- `tables/summary.json` quick run summary

- `figures/` plots for the above metrics

## Interpretation (what is *actually* being measured?)
This dataset suggests `macro:say` is best treated as:

- **A motor-gated emission event** (when the system opens an actuation aperture)
- With **content rendered by an external Markov composer**
- Seeded by recently ingested tokens (during input) or by internal topic symbols (during silence)

Meaning: the *timing* is a genuine internal signal; the *wording* is largely a lossy renderer.

## Reproduce
Run the script in `scripts/utd_parse_and_composer_audit.py`.

It writes the same tables/figures into a fresh output folder.

