# VDM 10k H5 snapshot structural validation (v1)

This package analyzes the **10,000-node connectome checkpoints** you uploaded:

- state_21720.h5
- state_21780.h5
- state_21840.h5
- state_21900.h5
- state_21960.h5

These contain:
- `sparse/row_ptr`, `sparse/col_idx` (CSR adjacency, directed)
- `sparse/W` (node field)
- `adc_json` (ADC territory metadata)

## Core confirmations
- All five checkpoints have `len(W)=10000` and ~`nnz≈239,8xx` directed edges.
- Mean out-degree is ~24 across snapshots, but **max degree and inequality fluctuate**.
- `adc_json` territory structure changes sharply at tick 21960 (territories drop from 6 to 1, total territory mass collapses).

## What we computed (offline, sparse)
Per snapshot:
- Edge count, degree stats (in/out), Gini (in/out)
- Power-law tail exponent (continuous MLE) at fixed kmin=13 and kmin=21
- W distribution stats and W↔degree correlations
- Reciprocity estimate via edge sampling
- Louvain community partition on undirectedized graph (n communities, modularity, community size stats)
- First 10 smallest eigenvalues of the normalized Laplacian (spectral fingerprint)
- ADC territory count and mass summary from adc_json

Between consecutive snapshots:
- Directed edge Jaccard similarity + added/removed counts
- Nodewise vs distribution-stable correlations for W and out-degree
- Hub persistence for top-k out-degree nodes
- Community stability (NMI/ARI)
- Spectral drift (L2 distance between eigenvalue vectors)

## Key reading notes
- Edge Jaccard is extremely low between consecutive snapshots in this slice (≈0.14%–0.35%).
  This can happen even when the degree distribution is fairly stable; it indicates **high turnover / rewiring**,
  not necessarily loss of global invariants.
- Nodewise W correlation is near 0, while sorted-W correlation is ~1.0. This indicates the **distribution**
  of W is stable while **which node holds which W** is not (consistent with representational drift / role exchangeability).
- Fixed-kmin tail exponents (kmin=13) are relatively stable (~1.84–2.20), but inequality spikes at tick 21900.

## Files
- tables/snapshot_metrics.csv : all per-snapshot metrics
- tables/drift_metrics.csv : consecutive drift metrics
- tables/snapshot_top_hubs.csv : top-50 out-degree hubs and top-50 W nodes per snapshot
- tables/community_labels_<tick>.csv.gz : Louvain community id per node (10k rows)
- figures/*.png : time-series, CCDFs, heatmaps
- scripts/run_10k_h5_snapshot_analysis.py : reproduction script

## Important limitation (for alignment with scalar macrostates/B1/detector)
The event logs currently available in this environment cover ticks **15360–16912** (not 21720–21960),
so this package **does not** align snapshot intervals to scalar B1 spikes, macro transitions, or detector episodes.
If you later provide the matching `events.jsonl` slice for ~21700–22000, we can do the full alignment test:
"do structural drift spikes coincide with B1 / macro transitions / detector-hot windows?"
