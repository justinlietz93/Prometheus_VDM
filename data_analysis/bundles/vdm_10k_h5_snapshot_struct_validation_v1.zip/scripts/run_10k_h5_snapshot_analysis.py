#!/usr/bin/env python3
"""Reproduce the 10k H5 snapshot structural metrics and drift tables.

Usage:
  python run_10k_h5_snapshot_analysis.py --input_dir /path/to/h5s --out_dir ./out

This script is intentionally self-contained (no runtime dependencies on your repo).
"""

import argparse, glob, os, re, json, gzip, csv
import numpy as np
import pandas as pd
import h5py
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import networkx as nx
from scipy import stats
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score

def gini(x):
    x = np.asarray(x, dtype=np.float64)
    if x.size == 0:
        return np.nan
    if np.all(x == 0):
        return 0.0
    if np.min(x) < 0:
        x = x - np.min(x)
    x_sorted = np.sort(x)
    n = x_sorted.size
    cumx = np.cumsum(x_sorted)
    return float((n + 1 - 2.0 * np.sum(cumx) / cumx[-1]) / n)

def powerlaw_fit_continuous(x, kmin):
    x = np.asarray(x, dtype=np.float64)
    xt = x[x >= kmin]
    n = xt.size
    if n < 50:
        return {"kmin": int(kmin), "alpha": np.nan, "ks": np.nan, "n_tail": int(n)}
    alpha = 1.0 + n / np.sum(np.log(xt / kmin))
    xs = np.sort(xt)
    ccdf_emp = (n - np.arange(n)) / n
    ccdf_the = (xs / kmin) ** (1.0 - alpha)
    ks = float(np.max(np.abs(ccdf_emp - ccdf_the)))
    return {"kmin": int(kmin), "alpha": float(alpha), "ks": ks, "n_tail": int(n)}

def build_undirected_adjacency(row_ptr, col_idx, N):
    out_deg = np.diff(row_ptr).astype(np.int32)
    rows = np.repeat(np.arange(N, dtype=np.int32), out_deg)
    cols = col_idx.astype(np.int32)
    A = sp.coo_matrix((np.ones(rows.size, dtype=np.float32), (rows, cols)), shape=(N,N))
    A = A + A.T
    A.data[:] = 1.0
    A = A.tocsr()
    A.setdiag(0)
    A.eliminate_zeros()
    return A, rows, cols

def laplacian_eigs(A, k=10, tol=1e-3):
    N = A.shape[0]
    deg = np.array(A.sum(axis=1)).ravel()
    deg_safe = np.where(deg > 0, deg, 1.0)
    D_inv_sqrt = sp.diags(1.0/np.sqrt(deg_safe))
    L = sp.eye(N, format='csr') - D_inv_sqrt @ A @ D_inv_sqrt
    vals = spla.eigsh(L, k=k, which='SM', return_eigenvectors=False, tol=tol)
    return np.sort(vals)

def louvain_labels(G, seed=0):
    comms = nx.algorithms.community.louvain_communities(G, seed=seed)
    labels = np.empty(G.number_of_nodes(), dtype=np.int32)
    for cid, c in enumerate(comms):
        labels[list(c)] = cid
    modularity = float(nx.algorithms.community.modularity(G, comms))
    sizes = np.array([len(c) for c in comms])
    return labels, modularity, sizes

def parse_adc(b):
    try:
        return json.loads(b.decode('utf-8'))
    except Exception:
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input_dir', required=True)
    ap.add_argument('--out_dir', required=True)
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    os.makedirs(os.path.join(args.out_dir,'tables'), exist_ok=True)

    h5s = sorted(glob.glob(os.path.join(args.input_dir,'state_*.h5')),
                 key=lambda p:int(re.findall(r'state_(\d+)\.h5', os.path.basename(p))[0]))
    snapshot_rows=[]
    top_hubs=[]
    comm_labels={}
    eigs={}
    edgesets={}
    Ws={}
    Degs={}

    for path in h5s:
        tick=int(re.findall(r'state_(\d+)\.h5', os.path.basename(path))[0])
        with h5py.File(path,'r') as f:
            row_ptr=f['sparse/row_ptr'][:]
            col_idx=f['sparse/col_idx'][:]
            W=f['sparse/W'][:].astype(np.float64)
            adc=parse_adc(f['adc_json'][()])
        N=W.size
        nnz=int(row_ptr[-1])
        out_deg=np.diff(row_ptr).astype(np.int32)
        in_deg=np.bincount(col_idx.astype(np.int64), minlength=N).astype(np.int32)

        # fixed tail fits
        fit13=powerlaw_fit_continuous(out_deg, 13)
        fit21=powerlaw_fit_continuous(out_deg, 21)

        # undirected graph + louvain + eigs
        A_und, rows, cols = build_undirected_adjacency(row_ptr, col_idx, N)
        ev = laplacian_eigs(A_und, k=10, tol=1e-3)
        eigs[tick]=ev

        G = nx.Graph()
        G.add_edges_from(zip(rows.tolist(), cols.tolist()))
        labels, modularity, sizes = louvain_labels(G, seed=0)
        comm_labels[tick]=labels

        # store edge set (directed encoding)
        edge_enc = rows.astype(np.int64)*N + cols.astype(np.int64)
        edge_enc.sort()
        edgesets[tick]=edge_enc
        Ws[tick]=W
        Degs[tick]=out_deg

        snapshot_rows.append({
            'tick': tick, 'N': N, 'nnz_edges': nnz,
            'out_deg_mean': float(out_deg.mean()), 'out_deg_max': int(out_deg.max()),
            'deg_gini_out': gini(out_deg), 'deg_gini_in': gini(in_deg),
            'alpha_kmin13': fit13['alpha'], 'ks_kmin13': fit13['ks'], 'n_tail13': fit13['n_tail'],
            'alpha_kmin21': fit21['alpha'], 'ks_kmin21': fit21['ks'], 'n_tail21': fit21['n_tail'],
            'W_mean': float(W.mean()), 'W_var': float(W.var()),
            'n_communities': int(labels.max()+1), 'modularity': modularity,
            'lap_eig2': float(ev[1]),
            'adc_n_territories': len(adc.get('territories',[])) if isinstance(adc, dict) else np.nan
        })

        # hubs
        k=50
        top_deg_idx = np.argsort(out_deg)[-k:][::-1]
        for rank, idx in enumerate(top_deg_idx, start=1):
            top_hubs.append({'tick': tick, 'hub_type': 'out_degree', 'rank': rank, 'node': int(idx), 'value': int(out_deg[idx])})

    snap_df=pd.DataFrame(snapshot_rows).sort_values('tick')
    snap_df.to_csv(os.path.join(args.out_dir,'tables','snapshot_metrics.csv'), index=False)
    pd.DataFrame(top_hubs).to_csv(os.path.join(args.out_dir,'tables','snapshot_top_hubs.csv'), index=False)

    # drift
    ticks = list(snap_df['tick'])
    drift=[]
    for t1,t2 in zip(ticks[:-1], ticks[1:]):
        E1=edgesets[t1]; E2=edgesets[t2]
        inter=np.intersect1d(E1,E2,assume_unique=True).size
        union=E1.size+E2.size-inter
        jacc=inter/union
        W1=Ws[t1]; W2=Ws[t2]
        d1=Degs[t1].astype(np.float64); d2=Degs[t2].astype(np.float64)
        lab1=comm_labels[t1]; lab2=comm_labels[t2]
        drift.append({
            'tick1': t1, 'tick2': t2, 'dt': t2-t1,
            'edge_jaccard': float(jacc),
            'corrW_node': float(np.corrcoef(W1,W2)[0,1]),
            'corrW_sorted': float(np.corrcoef(np.sort(W1),np.sort(W2))[0,1]),
            'corrOutDeg_node': float(np.corrcoef(d1,d2)[0,1]),
            'corrOutDeg_sorted': float(np.corrcoef(np.sort(d1),np.sort(d2))[0,1]),
            'community_nmi': float(normalized_mutual_info_score(lab1,lab2)),
            'community_ari': float(adjusted_rand_score(lab1,lab2)),
        })
    pd.DataFrame(drift).to_csv(os.path.join(args.out_dir,'tables','drift_metrics.csv'), index=False)

if __name__ == '__main__':
    main()
