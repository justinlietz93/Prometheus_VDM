#!/usr/bin/env python3
"""
VDM deep transduction + regime + PCA analysis (1k run) — optimized version.

Reproduces the outputs in this bundle from:
  Prometheus_VDM/runs/original_1kN_20250811_234347/1000_neurons_events.zip

Optional (recommended): attach existing regime labels + change_score from:
  status_1k_with_say_and_regime.csv

Key design choices:
- macro:say text content is NOT interpreted as semantics; only timestamps are used.
- Input "content embedding" is a lightweight HashingVectorizer + low-rank SVD (fit on a subsample for speed).
"""
import argparse, json, zipfile, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.cluster import MiniBatchKMeans, KMeans
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import r2_score, roc_auc_score, adjusted_rand_score, normalized_mutual_info_score

def sha256_file(path: Path, chunk=1<<20) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b=f.read(chunk)
            if not b: break
            h.update(b)
    return h.hexdigest()

def segments_from_labels(labels):
    seg=[]
    i=0
    n=len(labels)
    while i<n:
        s=labels[i]
        j=i+1
        while j<n and labels[j]==s:
            j+=1
        seg.append((int(s), int(i), int(j-1), int(j-i)))
        i=j
    return pd.DataFrame(seg, columns=["state","start_idx","end_idx","dwell"])

def smooth_short_segments(labels, min_len=10, max_passes=5):
    labels = labels.copy()
    n=len(labels)
    for _ in range(max_passes):
        seg = segments_from_labels(labels)
        changed=False
        for _, row in seg.iterrows():
            if row["dwell"] < min_len:
                i = int(row["start_idx"]); j=int(row["end_idx"])
                left = labels[i-1] if i>0 else None
                right = labels[j+1] if j+1<n else None
                if left is None and right is None:
                    continue
                # choose neighbor with larger local run length
                def run_len(pos):
                    lab = labels[pos]
                    l=pos
                    while l>0 and labels[l-1]==lab: l-=1
                    r=pos
                    while r+1<n and labels[r+1]==lab: r+=1
                    return lab, (r-l+1)
                best=None
                if left is not None:
                    lab,ll=run_len(i-1); best=(ll,lab)
                if right is not None:
                    lab,rr=run_len(j+1)
                    if best is None or rr>best[0]:
                        best=(rr,lab)
                labels[i:j+1]=best[1]
                changed=True
        if not changed:
            break
    return labels

def implied_timescale(lam: float) -> float:
    lam = float(np.clip(lam, -0.999999, 0.999999))
    if lam <= 0:
        return float("nan")
    return float(-1.0/np.log(lam))

def macro_from_micro(P, micro_labels, k_macro=6, n_init=10):
    eigvals, eigvecs = np.linalg.eig(P)
    eigvals = np.real(eigvals)
    eigvecs = np.real(eigvecs)
    order=np.argsort(eigvals)[::-1]
    eigvecs=eigvecs[:, order]
    feats=eigvecs[:, 1:k_macro]
    feats = feats / (np.linalg.norm(feats, axis=1, keepdims=True)+1e-12)
    km=KMeans(n_clusters=k_macro, random_state=0, n_init=n_init, max_iter=300)
    micro_to_macro=km.fit_predict(feats)
    return micro_to_macro[micro_labels]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--run_dir", type=str, default="Prometheus_VDM/runs/original_1kN_20250811_234347/")
    ap.add_argument("--events_zip", type=str, default=None)
    ap.add_argument("--status_csv", type=str, default=None, help="optional; adds regime/change_score")
    ap.add_argument("--outdir", type=str, default="out_vdm_deep_transduction")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--micro_k", type=int, default=30)
    ap.add_argument("--topic_k", type=int, default=12)
    ap.add_argument("--perm_n", type=int, default=200)
    ap.add_argument("--hash_n_features_pow", type=int, default=14, help="hashing vectorizer features = 2^pow")
    ap.add_argument("--emb_dim", type=int, default=8)
    ap.add_argument("--emb_fit_rows", type=int, default=6000)
    args=ap.parse_args()

    rng=np.random.default_rng(args.seed)

    run_dir=Path(args.run_dir)
    out=Path(args.outdir)
    (out/"results").mkdir(parents=True, exist_ok=True)
    (out/"plots").mkdir(parents=True, exist_ok=True)
    (out/"provenance").mkdir(parents=True, exist_ok=True)

    events_zip = Path(args.events_zip) if args.events_zip else run_dir/"1000_neurons_events.zip"
    assert events_zip.exists(), f"Missing {events_zip}"

    work=out/"_extract"
    if work.exists():
        import shutil; shutil.rmtree(work)
    work.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(events_zip,"r") as zf:
        zf.extractall(work)

    events_jsonl = work/"events.jsonl"
    utd_jsonl = work/"utd_events.jsonl"
    assert events_jsonl.exists() and utd_jsonl.exists()

    # load tick telemetry
    tick_rows=[]
    with events_jsonl.open("r", encoding="utf-8") as f:
        for line in f:
            obj=json.loads(line)
            if obj.get("msg")=="tick":
                tick_rows.append(obj)
    tick=pd.DataFrame(tick_rows).sort_values("t").reset_index(drop=True)

    # parse utd: align text to ticks
    input_rows=[]
    say_rows=[]
    current_t=None
    current_phase=None
    with utd_jsonl.open("r", encoding="utf-8") as f:
        for line in f:
            obj=json.loads(line)
            if obj.get("type")=="text":
                payload=obj.get("payload",{})
                if payload.get("type")=="status":
                    current_t=int(payload.get("t"))
                    current_phase=payload.get("phase", current_phase)
                elif payload.get("type")=="text":
                    if current_t is not None:
                        input_rows.append({"t": current_t, "phase": current_phase, "msg": payload.get("msg","")})
            elif obj.get("type")=="macro" and obj.get("macro")=="say":
                args=obj.get("args",{}) or {}
                why=args.get("why",{}) or {}
                t=why.get("t", args.get("t", None))
                if t is not None:
                    say_rows.append({"t": int(t)})

    inputs=pd.DataFrame(input_rows)
    say=pd.DataFrame(say_rows)
    inputs["msg_len"]=inputs["msg"].astype(str).str.len()
    agg = inputs.groupby("t").agg(input_msgs=("msg","count"), input_chars=("msg_len","sum")).reset_index()
    say_agg = say.groupby("t").size().reset_index(name="say_events")
    ts = tick.merge(agg, on="t", how="left").merge(say_agg, on="t", how="left")
    for c in ["input_msgs","input_chars","say_events"]:
        ts[c]=ts[c].fillna(0).astype(int)
    ts["did_say"]=(ts["say_events"]>0).astype(int)

    # attach regime/change_score if provided
    if args.status_csv:
        st=pd.read_csv(args.status_csv)
        st=st[st["neurons"]==1000].drop_duplicates(subset=["t"])[["t","regime","change_score","say_count"]]
        ts=ts.merge(st, on="t", how="left")
    ts_reg=ts.dropna(subset=["regime"]).copy()
    ts_reg["regime"]=ts_reg["regime"].astype(int)

    # select internal features
    num_cols=ts_reg.select_dtypes(include=[np.number]).columns.tolist()
    exclude=set(["t","ts","phase","did_say","say_events","input_msgs","input_chars","regime","change_score","say_count","ute_in_count","ute_text_count"])
    feats=[c for c in num_cols if c not in exclude]
    X=ts_reg[feats].to_numpy(float)
    m=np.all(np.isfinite(X), axis=1)
    X=X[m]; ts_reg=ts_reg.iloc[np.where(m)[0]].reset_index(drop=True)
    sd=X.std(axis=0)
    keep=sd>1e-12
    feats=[f for f,k in zip(feats,keep) if k]
    X=X[:, keep]

    Xz=StandardScaler().fit_transform(X)
    pca=PCA(n_components=min(20, Xz.shape[1]))
    Z=pca.fit_transform(Xz)

    pd.DataFrame({"PC":[f"PC{i+1}" for i in range(len(pca.explained_variance_ratio_))],
                  "explained_variance_ratio":pca.explained_variance_ratio_}).to_csv(out/"results"/"pca_evr.csv", index=False)

    # microstates from first 8 PCs
    Z8=Z[:, :8]
    mb=MiniBatchKMeans(n_clusters=args.micro_k, random_state=args.seed, batch_size=512, max_iter=200, n_init=3)
    micro=mb.fit_predict(Z8)

    P=np.zeros((args.micro_k, args.micro_k), float)
    for a,b in zip(micro[:-1], micro[1:]):
        P[a,b]+=1
    denom=P.sum(axis=1, keepdims=True)
    P=np.divide(P, denom, out=np.zeros_like(P), where=denom>0)

    eigvals=np.real(np.linalg.eigvals(P))
    eigvals=np.sort(eigvals)[::-1]
    eig_df=pd.DataFrame({"rank":np.arange(1,len(eigvals)+1), "eigenvalue":eigvals})
    eig_df["implied_timescale_steps"]=[np.inf if i==0 else implied_timescale(l) for i,l in enumerate(eigvals)]
    eig_df.to_csv(out/"results"/"micro_eigenspectrum.csv", index=False)

    # macrostates (k=6 + smoothing)
    macro6=macro_from_micro(P, micro, k_macro=6)
    macro6_s10=smooth_short_segments(macro6, min_len=10)
    pd.DataFrame({"t":ts_reg["t"], "regime":ts_reg["regime"], "micro":micro, "macro6":macro6, "macro6_s10":macro6_s10,
                  "did_say":ts_reg["did_say"], "input_msgs":ts_reg["input_msgs"],
                  "ute_text_count":ts_reg["ute_text_count"], "change_score":ts_reg.get("change_score", np.nan)}).to_csv(out/"results"/"states_over_time.csv", index=False)

    # input embedding
    tick_text = inputs.groupby("t")["msg"].apply(lambda s: " ".join([str(x) for x in s.tolist()])[:400]).to_dict()
    docs=[tick_text.get(int(t), "") for t in ts_reg["t"].to_numpy(int)]
    hv = HashingVectorizer(n_features=2**args.hash_n_features_pow, alternate_sign=False, norm="l2", lowercase=True)
    Xh = hv.transform(docs)
    fit_rows=min(args.emb_fit_rows, Xh.shape[0])
    sample_idx=rng.choice(np.arange(Xh.shape[0]), size=fit_rows, replace=False)
    svd=TruncatedSVD(n_components=args.emb_dim, random_state=args.seed, n_iter=2)
    svd.fit(Xh[sample_idx])
    E=StandardScaler().fit_transform(svd.transform(Xh))

    # incremental next-step PC prediction (PC1..PC6)
    Y=Z[:, :6]
    Y_next=Y[1:]; Y_curr=Y[:-1]
    E_curr=E[:-1]
    inp = np.c_[ts_reg["input_msgs"].to_numpy(int)[:-1], ts_reg["ute_text_count"].to_numpy(int)[:-1], ts_reg["ute_in_count"].to_numpy(int)[:-1]]
    split=int(0.7*len(Y_curr))

    base=Ridge(alpha=1.0, random_state=args.seed).fit(Y_curr[:split], Y_next[:split])
    pred_b=base.predict(Y_curr[split:])
    augX=np.c_[Y_curr, E_curr, inp]
    aug=Ridge(alpha=1.0, random_state=args.seed).fit(augX[:split], Y_next[:split])
    pred_a=aug.predict(augX[split:])

    def mean_r2(Yt,Yp):
        return float(np.mean([r2_score(Yt[:,d], Yp[:,d]) for d in range(Yt.shape[1])]))
    pd.DataFrame([{"r2_mean_base":mean_r2(Y_next[split:], pred_b),
                   "r2_mean_aug":mean_r2(Y_next[split:], pred_a)}]).to_csv(out/"results"/"delta_r2_nextpcs.csv", index=False)

    # incremental next-step say prediction
    y_next=ts_reg["did_say"].to_numpy(int)[1:]
    Xb=Y_curr
    Xa=np.c_[Y_curr, E_curr, inp]
    clf_b=Pipeline([("sc", StandardScaler()), ("lr", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=args.seed))])
    clf_a=Pipeline([("sc", StandardScaler()), ("lr", LogisticRegression(max_iter=2000, class_weight="balanced", random_state=args.seed))])
    clf_b.fit(Xb[:split], y_next[:split])
    clf_a.fit(Xa[:split], y_next[:split])
    pb=clf_b.predict_proba(Xb[split:])[:,1]
    pa=clf_a.predict_proba(Xa[split:])[:,1]
    pd.DataFrame([{"auc_base":roc_auc_score(y_next[split:], pb),
                   "auc_aug":roc_auc_score(y_next[split:], pa)}]).to_csv(out/"results"/"delta_auc_nextsay.csv", index=False)

    # topic boundaries vs regime-change alignment
    input_ticks=sorted(tick_text.keys())
    docs_in=[tick_text[t] for t in input_ticks]
    Ein=StandardScaler().fit_transform(svd.transform(hv.transform(docs_in)))
    km=MiniBatchKMeans(n_clusters=args.topic_k, random_state=args.seed, batch_size=512, max_iter=200, n_init=3)
    topic=km.fit_predict(Ein)
    topic_df=pd.DataFrame({"t":input_ticks, "topic":topic})
    topic_df["prev"]=topic_df["topic"].shift(1)
    b = topic_df.loc[topic_df["topic"]!=topic_df["prev"], "t"].to_numpy(int)
    # filter spacing
    bf=[]; last=-10**9
    for tt in b:
        if tt-last>=20:
            bf.append(tt); last=tt
    bf=np.array(bf,int)

    reg=ts_reg["regime"].to_numpy(int)
    tt=ts_reg["t"].to_numpy(int)
    reg_change_t = tt[np.where(np.diff(reg)!=0)[0]]

    def nearest_within(events, anchors, W=50):
        anchors=np.sort(anchors)
        within=[]
        for e in events:
            j=np.searchsorted(anchors, e)
            cand=[]
            if j<len(anchors): cand.append(abs(e-anchors[j]))
            if j>0: cand.append(abs(e-anchors[j-1]))
            dt=min(cand) if cand else np.inf
            within.append(int(dt<=W))
        return float(np.mean(within)) if len(within)>0 else float("nan")

    W=50
    obs=nearest_within(bf, reg_change_t, W=W)
    tmin=tt.min(); tmax=tt.max(); span=tmax-tmin
    perm=[]
    for _ in range(args.perm_n):
        shift=int(rng.integers(0, span))
        bsh=((bf-tmin+shift)%span)+tmin
        perm.append(nearest_within(bsh, reg_change_t, W=W))
    perm=np.array(perm,float)
    p=(np.sum(perm>=obs)+1)/(len(perm)+1)
    pd.DataFrame([{"W":W,"obs_within_rate":obs,"p_value":p,"perm_mean":float(np.nanmean(perm))}]).to_csv(out/"results"/"topic_boundary_regime_alignment.csv", index=False)

    # write provenance hashes
    meta={
        "events_zip": str(events_zip),
        "sha256_events_zip": sha256_file(events_zip),
        "sha256_events_jsonl": sha256_file(events_jsonl),
        "sha256_utd_events_jsonl": sha256_file(utd_jsonl),
        "status_csv": str(args.status_csv) if args.status_csv else None,
    }
    (out/"provenance"/"run_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    rows=[]
    for pth in out.rglob("*"):
        if pth.is_file():
            rows.append({"path": str(pth.relative_to(out)), "sha256": sha256_file(pth)})
    pd.DataFrame(rows).sort_values("path").to_csv(out/"provenance"/"SHA256_INDEX.csv", index=False)

    print("done:", out)

if __name__ == "__main__":
    main()
