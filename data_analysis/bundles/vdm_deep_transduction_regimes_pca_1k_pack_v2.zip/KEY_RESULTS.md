# Key results (composer-agnostic)

## “More regimes?” evidence via microstate transition spectrum
Microstates: K=30 on first 8 PCs. Eigenvalues of the microstate transition matrix show a clear separation:

Top eigen-modes (rank, eigenvalue, implied timescale in steps):
- 1: 1.000000  (τ≈inf)
- 2: 0.997804  (τ≈454.85)
- 3: 0.976294  (τ≈41.68)
- 4: 0.944444  (τ≈17.50)
- 5: 0.885733  (τ≈8.24)
- 6: 0.842506  (τ≈5.84)
- 7: 0.398327  (τ≈1.09)
- 8: 0.161707  (τ≈0.55)
- 9: 0.138441  (τ≈0.51)
- 10: 0.079078  (τ≈0.39)

Practical reading:
- Several eigenvalues are close to 1 (slow modes) before a big drop — consistent with **~4–6 metastable macrostates** (macro-regimes) rather than a single stationary mode.

See:
- plots/microstate_eigenvalues.png
- plots/microstate_implied_timescales.png

## “Is input content driving internal dynamics?”
We tested whether a lightweight **input content embedding** adds predictive power for **next-step internal PCs**, beyond internal autocorrelation.

- Mean R² (next PC prediction), baseline (PC_t → PC_371658): **0.3221**
- Mean R², augmented (PC_t + input_embedding_t + counts → PC_371658): **0.4561**
- ΔR²: **0.1340**

Interpretation:
- Positive ΔR² means input carries **directed influence** into internal state evolution (small but measurable with current low-dimensional telemetry).

## “Does input help predict actuation (say)?”
We predicted **did_say at t+1** from PCs vs PCs+input embedding.

- AUC baseline: **0.9333**
- AUC augmented: **0.9278**
- ΔAUC: **-0.0055**

Interpretation:
- If ΔAUC is near zero, the actuation gate is largely internal-state driven (input affects it mainly through internal dynamics).
- If ΔAUC > 0, there is a direct input→actuation effect.

## Topic boundary alignment with internal reconfiguration
We clustered input ticks into K=12 coarse topics (fast embedding+MiniBatchKMeans), then detected topic boundaries and asked whether they align with internal events.

Observed rates (within ±50 ticks):
- within regime-change rate: **1.000** (median Δt=2.0)
- within change_score spike rate: **0.541** (median Δt=44.5)

Permutation p-values (circular shift null):
- p(regime alignment): **0.1692**
- p(spike alignment): **0.0199**

Interpretation:
- Small p-values → topic transitions are coupled to internal regime transitions / reconfiguration spikes more than chance.

## Say modes (motor actuation context)
Say events were split into:
- reactive: input_msgs_at_t > 0 and dt_since_input==0
- near_reactive: dt_since_input ≤ 5
- autonomous: otherwise

See:
- results/say_modes_with_PCs.csv
- plots/say_mode_counts.png
- plots/say_mode_PC1_hist.png
