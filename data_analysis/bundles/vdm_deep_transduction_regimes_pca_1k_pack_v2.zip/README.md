# VDM deep transduction + regimes + PCA (1k run) — v2

This package continues the analysis deeper, but stays **composer-agnostic**:
- `macro:say` text content is **not** treated as semantics
- only `say` **timestamps** are used as a motor-actuation signal

## Raw data location (repo)
You specified:
`Prometheus_VDM/runs/original_1kN_20250811_234347/`

This analysis expects:
- `Prometheus_VDM/runs/original_1kN_20250811_234347/1000_neurons_events.zip`
  - `events.jsonl` (tick telemetry)
  - `utd_events.jsonl` (inputs + macro say timestamps)

Optional:
- `status_1k_with_say_and_regime.csv` (for existing regime labels + change_score)

## Reproduce
```bash
python scripts/run_vdm_deep_transduction_regimes_pca_1k.py \
  --run_dir Prometheus_VDM/runs/original_1kN_20250811_234347 \
  --status_csv status_1k_with_say_and_regime.csv \
  --outdir out_vdm_deep_transduction_v2
```

Outputs:
- `results/` CSVs
- `plots/` PNGs
- `provenance/SHA256_INDEX.csv` for integrity

## How to read the “more regimes” result
The key evidence is the **eigen-spectrum** of the microstate transition matrix (K=30 microstates).
Multiple eigenvalues close to 1 imply multiple slow modes → consistent with **multiple metastable macrostates** (macro-regimes).

See:
- `plots/microstate_eigenvalues.png`
- `plots/microstate_implied_timescales.png`
- `results/microstate_transition_eigenspectrum.csv`

## Composer-agnostic “content influence” test
We test whether a lightweight embedding of input text (hashing + SVD) adds predictive power for next-step internal PCs beyond internal autocorrelation:
- `results/input_embedding_incremental_r2_next_PC.csv`
- `results/input_embedding_incremental_r2_per_PC.csv`
- `plots/delta_r2_input_embedding_per_pc.png`

This does not assume the text output is meaningful — it only tests whether **input content affects internal dynamics** in a measurable way.
