# VDM log slice analysis (scalar + sparse structure proxies)

This package analyzes the provided log slice **offline-only** (no runtime changes).

## Inputs used

- `events.jsonl` (tick telemetry, includes `evt_trail_dict` + `evt_memory_dict`)
- `utd_events.jsonl` (macro events, includes `macro:say` with tick in `args.why.t`)

## Tick span

- ticks: **1553**
- t range: **15360 .. 16912**
- `did_say` events: **12**

## Input episodes (from `ute_text_count>0`, gap-close=2, min_len=3)

Detected episodes: **3**
Episode durations (ticks):
input_episode_id
0    345
1    255
2    510
3    443

> Note: `ute_in_count` is nonzero almost everywhere in this slice; `ute_text_count` provides the meaningful "text input present" signal.

## Macrostate refit (internal-only; excludes UTE/UTD columns + excludes our derived trail/memory summaries)

- microstates: 25 (kmeans on top PCA modes)
- inferred macrostates (spectral gap heuristic): **2**

Macrostate occupancy (ticks):
macro_refit
0     399
1    1154

`did_say` concentration:
- did_say counts by macro: {0: 11, 1: 1}
- did_say rates by macro: {0: 0.02756892230576441, 1: 0.0008665511265164644}

Mutual information sanity (not trivially driven by has_input/did_say):
- NMI(macro, has_input) ~ 0.112
- NMI(macro, did_say) ~ 0.025

## Sparse structure proxies from `evt_trail_dict` / `evt_memory_dict`

Per-tick computed features include:
- mass, entropy, Gini, participation ratio
- tail exponent alpha via continuous MLE above per-tick p90
- drift vs previous tick: cosine similarity + top-k Jaccard

Heavy-tail stability (overall):
- trail: gini mean=0.712 std=0.007; alpha mean=1.937 std=0.071
- memory: gini mean=0.787 std=0.005; alpha mean=1.613 std=0.051

## Communication-window detector lead-time (simple version)

Detector definition (tunable):
- `macro_refit == 0` (the macrostate enriched for did_say in this slice)
- `has_input == 1`
- `b1_z > threshold`

Lead-time is measured as: **ticks between did_say(t) and the most recent detector-hot tick BEFORE t** (within a 50 tick lookback window).

Key summaries:
- threshold 0.5: median=4.0 mean=3.5 max=7.0
- threshold 0.9: median=5.5 mean=6.7 max=18.0

Interpretation: using b1_z as an early-warning “boundary build-up” signal can give a **~5–10 tick** listen window in this slice, depending on threshold.

## Macrostate-conditioned directed influence (regression ΔR² proxy)

We estimate directed influence as improvement in predicting next-step Y from lag-1 Y when adding lag-1 X (time-ordered 70/30 split where possible).
See:
- `tables/macrostate_directed_influence_deltaR2.csv`
- `tables/macrostate_goal_entropy_drive_summary.csv`

For this slice (Y = vt_coverage as exploration proxy):
 macro  n_pairs  dr2_entropy_to_expl  dr2_reward_to_expl  goal_drive_index  reward_entropy_ratio
     0      380             0.085100            0.049447         -0.035652              0.581053
     1     1135             0.150099            0.070194         -0.079905              0.467653

## Files

- `tables/tick_table_full.csv.gz` — unified tick table with derived columns (macro_refit, has_input, did_say, trail/memory summaries)
- `tables/*` — micro/macro transition matrices, ETAs, detector lead times, directed influence tables
- `figures/*` — timeseries plots, ETA plots, lead-time histograms
- `scripts/analyze_scalar_struct_from_logs.py` — reproduction script
- `SHA256SUMS.csv` — checksums for all artifacts in this package

## Reproduce

```bash
python3 scripts/analyze_scalar_struct_from_logs.py \
  --events /path/to/events.jsonl \
  --utd /path/to/utd_events.jsonl \
  --out /path/to/output_dir
```

