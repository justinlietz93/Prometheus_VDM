# Consciousness metrics suite (non-ML)

This folder contains *new* result sets focused on consciousness-adjacent metrics from neuroscience / complex systems,
computed directly from `consciousness_package/data/timeseries_core_renamed.csv` and `pca_state_space.csv`.

Important: these are **signatures** associated with conscious/unconscious dynamics in *some* theories and datasets.
They are **not** proof of consciousness.

## Epoch definitions (data-driven)
High-entropy plateau detected as the longest contiguous segment with `entropy > 6.4`:
- E1_low_entropy_baseline_1: ticks 257–9180
- E2_high_entropy_plateau:   ticks 9181–11344
- E3_low_entropy_baseline_2: ticks 11345–15039

(An initial short high-entropy segment exists at ticks 0–256 and is labeled E0 in some files.)

## Key deliverables

### 1) State repertoire / differentiation
- `lz_complexity_pca_sign_timeseries.csv/png`
  Sliding-window Lempel–Ziv (LZ) complexity of **sign-binarized** PCA state (PC1–PC3).  
  Interpretable as a coarse "state repertoire" / differentiation proxy.

### 2) Integration & synergy
- `window_TC_DTC_O.csv`, `TC_timeseries.png`, `O_information_timeseries.png`
  Gaussian Total Correlation (TC), Dual TC (DTC), and O-information (O = TC − DTC) computed in sliding windows
  over variables:
  `entropy, complexity, firing_var(log), reward_mean, valence_01, novelty, td_error, void_unique(log), text_words(log1p)`.

- `mip_integration_timeseries.csv`, `mip_integration_timeseries_(linear|log).png`
  "Minimum Information Partition" (MIP) integration proxy:
  for each window, find the bipartition (A,B) that **minimizes** Gaussian mutual information I(A;B).
  This yields a *bottleneck coupling* measure: larger values mean *no easy cut* → more globally integrated.

- `mip_singleton_variable_counts.png`, `mip_singleton_counts_by_epoch.csv`
  Which variable most often becomes the "minimum cut" singleton.

### 3) Perturbational complexity proxy (PCI-like)
- `pci_like_events.csv`, `pci_like_controls.csv`, `pci_like_*png`
  Event-triggered LZ complexity of post-event spatiotemporal deviations (|z|>2) across 12 variables,
  multiplied by active density (a PCI-like proxy).
  Events are the 30 most salient internal-change ticks (spaced ≥200 ticks) based on combined spikes in:
  TD error, entropy jumps, PCA speed, void-unique jumps.

### 4) Memory / temporal integration
- `predictive_MI_vs_lag_PCA.csv/png`, `predictive_MI_top_peaks_PCA_by_epoch.csv`, `predictive_MI_auc_summary.csv`
  Gaussian mutual information between PCA state at time t and t+lag, for lag 1..1000, by epoch.
  Captures predictability + rhythmic recurrence (peaks near ~315 ticks).

### 5) Causal density (Seth-style proxy)
- `granger_fast_*`
  Fast linear Granger-style tests using OLS on lagged predictors (p=5) across variables:
  `entropy, complexity, firing_var(log), reward_mean, td_error, void_unique(log)`.
  Outputs p-value matrices, significance heatmaps, and epoch-level causal density.

### 6) Criticality / 1/f-like scaling
- `spectral_exponent_slopes.csv` and `spectral_slope_*.png`
  Log–log spectral slope fits over frequency range 0.002..0.1 cycles/tick for several signals.

### 7) Critical transition early warnings (bonus)
- `rolling_*entropy*`, `rolling_*pca_speed*`
  Rolling variance + lag-1 autocorrelation (win=500) for entropy and PCA speed.

## Notes / limitations
- All "Φ-like"/IIT measures here are **proxies**; true IIT Φ requires explicit system decomposition and
  cause–effect structure not present in this aggregate dataset.
- PCI is *defined* with an **external perturbation**; here we use internal salient events as perturbation proxies.
- Several measures are Gaussian / linear by construction and may miss nonlinear structure.

